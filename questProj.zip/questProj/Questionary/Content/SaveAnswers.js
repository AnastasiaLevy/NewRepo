﻿(function () {
    document.getElementById('save').addEventListener('click', function (event) {
        event.preventDefault();
        saveAnswers();
    });
})();

function saveAnswers() {
    data = [];
    valid = true;
    var answers = [].slice.call(document.getElementsByClassName("answer"));
    answers.forEach(getAnswers);
    download();
}

function getAnswers(item, index) {
    switch (item.getAttribute('type')) {
        case "checkbox":
            getCheckBoxAnswer(item);
            break;
        case "radio":
        case "likert":
            getRadioAnswer(item);
            break;
        case "datetime":
        case "textbox":
            getTextBoxAnswer(item);
            break;
        case "rbx":
            getRBXAnswer(item);
            break;
        case "dropdown":
            getDropDownAnswer(item);
            break;
    }
}

function getCheckBoxAnswer(item) {
    var checkboxes = item.getElementsByTagName('input');
    var checkedValues = [item.getAttribute('id')];
    for (var i = 0; checkboxes[i]; ++i) {
        if (checkboxes[i].checked) {
            checkedValues.push(checkboxes[i].value);
        }
    }
    if (item.hasAttribute('required') && checkedValues.length == 1) {
        valid = false;
    }
    data.push(checkedValues);

}

function getRadioAnswer(item) {
    var radios = item.getElementsByTagName('input');
    var checkedValue = [item.getAttribute('id')];
    for (var i = 0; radios[i]; ++i) {
        if (radios[i].checked) {
            checkedValue.push(radios[i].value);
            break;
        }
    }
    if (item.hasAttribute('required') && checkedValue.length == 1) {
        valid = false;
    }
    data.push(checkedValue);
}

function getTextBoxAnswer(item) {
    var inputs = item.getElementsByTagName('input');
    var values = [item.getAttribute('id')];
    for (var i = 0; inputs[i]; ++i) {
        if (inputs[i].value.trim()) {
            values.push(inputs[i].value);
        }
    }
    if (item.hasAttribute('required') && values.length == 1) {
        valid = false;
    }
    data.push(values);
}

function getRBXAnswer(item) {
    var textareas = item.getElementsByTagName('textarea');
    var values = [item.getAttribute('id')];
    for (var i = 0; textareas[i]; ++i) {
        if (textareas[i].value.trim())
            values.push(textareas[i].value);
    }
    if (item.hasAttribute('required') && values.length == 1) {
        valid = false;
    }
    data.push(values);
}

function getDropDownAnswer(item) {
    var select = item.getElementsByTagName('select');
    var value = [item.getAttribute('id')];
    for (var i = 0; select[i]; ++i) {
        if (select[i].selectedIndex != 0) {
            value.push(select[i][select[i].selectedIndex].value);
        }
    }
    if (item.hasAttribute('required') && value.length == 1) {

        valid = false;
    }
    data.push(value);
}

var data = [];
var valid = true;

function getMaxLengthInArray(masterArray) {
    var max = -Infinity;
    masterArray.forEach(function (a) {
        if (a.length > max) {
            max = a.length;
        }
    });
    return max;
}

function fillShortSubArrays(masterArray, maxLenght) {
    masterArray.forEach(function (a) {
        if (a.length < maxLenght) {
            for (i = 0; i < maxLenght - a.length; i++) {
                a.push('');
            }
        }
    });
}

function rotateArray(masterArray) {
    var maxLenght = getMaxLengthInArray(masterArray);
    fillShortSubArrays(masterArray, maxLenght);
    var rotated = [];
    for (i = 0; i < maxLenght; i++) {
        var row = [];
        for (j = 0; j < masterArray.length; j++) {
            row.push(masterArray[j][i]);
        }
        rotated.push(row);
    }
    return rotated;
}


function getCurrentDate(){    
    var d = new Date()
    var curDate = d.getMonth() + '-' + d.getDate() + '-' + d.getFullYear() + ' ' + d.getHours() + '_' + d.getMinutes() + '_' + d.getSeconds();
    return curDate;
}



function download() {
    if (!valid) {
        alert('Please answer all required(*) questions');
        return false;
    }
    var format = '{ANSWERSFORMAT}';
    var dataType = '';

    var _fileContent = '';

    var _questionnaireName = document.title;

    if (format == 'csv') {
        dataType = 'text / csv';
        _answers = rotateArray(data);
        _answers.forEach(function (row) {
            _fileContent += row.join('{SEPARATOR}');
            _fileContent += "\n";
        });
    }
    else {        
        _fileContent += "Questionnaire name: " + _questionnaireName + "\n";
        data.forEach(function (row) {
            var question = "Question: " + row[0] + "\n";
            _fileContent += question;
            var answer = "Answer: ";
            row.shift();
            if (row.length === 0) {
                _fileContent += answer + "(not given)" + "\n";
            }
            else {
                row.forEach(function (ans) {
                    _fileContent += answer + ans + "\n";
                });
            }
        });        
        dataType = 'text / plain'
    }
    
   
    
   
    var _currentDate = getCurrentDate();
    var _fileName = _questionnaireName + '_' + _currentDate;

    var hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:' + dataType + ';charset=utf-8,' + encodeURI(_fileContent);
    hiddenElement.target = '_blank';
    hiddenElement.download = _fileName + '.' + format;
    hiddenElement.click();
}