﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Questionary
{
    public partial class PanelLinear : UserControl
    {
        public PanelLinear()
        {
            InitializeComponent();
        }

        private void moFontLabel_Click(object sender, EventArgs e)
        {

        }

        private void moFontResponse_Click(object sender, EventArgs e)
        {

        }

        private void moTextAlign_Click(object sender, EventArgs e)
        {

        }

        private void borderToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
