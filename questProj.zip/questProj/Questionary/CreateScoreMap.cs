﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Questionary
{
    public static class CreateScoreMap
    {
        public static void ReadProps(string fileName)
        {
            CustomForm myObject;
            XmlSerializer mySerializer =
            new XmlSerializer(typeof(CustomForm));
            string filePath = Application.StartupPath + "\\tests" + @"\" + fileName;
            FileStream myFileStream =
            new FileStream(filePath, FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);
            myObject = (CustomForm)
            mySerializer.Deserialize(myFileStream);
            myFileStream.Dispose();

            ScoringMap sm = new ScoringMap();
            FlowLayoutPanel body = sm.Controls.Find("flpBody", true).FirstOrDefault() as FlowLayoutPanel;
            foreach (var c in myObject.FormBody.Responses)
            {
                ScoreCardPannel scp = new ScoreCardPannel();
                TextBox txtText = scp.Controls.Find("txtText", true).FirstOrDefault()as TextBox;
                txtText.Text = c.QuestionTitle.Settings.TextValue;
                TextBox txtType = scp.Controls.Find("txtType", true).FirstOrDefault() as TextBox;
                txtType.Text = c.Type;

                foreach (var box in c.Controls)
                {
                    if (box.Type == "checkbox")
                    {

                    }

                    body.Controls.Add(scp);
                }

            }
            sm.Show();


            }
    }
}
