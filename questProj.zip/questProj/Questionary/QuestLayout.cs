﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;


namespace Questionary
{

    public partial class QuestLayout : Form
    {
        public List<Control> list { get; set; }
        //Point move;
        int i = 0;
        ViewForm myForm = new ViewForm();

        private string filename;
        private string _answersFormat;
        private string _questionsId;

        public string SetFilName
        {
            get { return filename; }
            set { filename = value; }

        }
        static int currentY = 0;

        public QuestLayout()
        {
            InitializeComponent();
            flpMainForm.AutoScroll = true;
            lbQestionnaireName.BackColor = Color.Transparent;
            //textFormQuestToolStripMenuItem.Visible = false;
        }

        public QuestLayout(string answersFormat, string questionsId)
        {
            _answersFormat = answersFormat;
            _questionsId = questionsId;
            InitializeComponent();
            flpMainForm.AutoScroll = true;
            lbQestionnaireName.BackColor = Color.Transparent;
        }

        //================Controls Set Up=====================================
        #region


        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //ColorDialog cd = new ColorDialog();
            //cd.AllowFullOpen = false;
            //cd.SolidColorOnly = true;
            //cd.AnyColor = false;
            //if (cd.ShowDialog() == DialogResult.OK)
            //{
            //    cd.Color.ToKnownColor();
            //    txtTitle.ForeColor = cd.Color;
            //}
        }

        private void setTitleFontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {
                txtTitle.Font = fd.Font;

            }
        }

        private void backGroundToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.AllowFullOpen = false;
            cd.SolidColorOnly = true;
            cd.AnyColor = false;
            if (cd.ShowDialog() == DialogResult.OK)
            {
                cd.Color.ToKnownColor();
                flpMainForm.BackColor = cd.Color;
            }
        }

        private void QuestLayout_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.AllowFullOpen = false;

            cd.SolidColorOnly = true;
            cd.AnyColor = false;
            if (cd.ShowDialog() == DialogResult.OK)
            {
                cd.Color.ToKnownColor();
                flpMainForm.ForeColor = cd.Color;
            }
        }

        private void mainFormFontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            fd.AllowVectorFonts = false;
            if (fd.ShowDialog() == DialogResult.OK)
            {
                flpMainForm.Font = fd.Font;
            }
        }

        private void alignTitleToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            string txt = e.ClickedItem.Text;
            txtTitle.TextAlign = Util.MapTextAlign(txt);
        }
        #endregion

        //=====================Show Preview Form=============================
        private void btnPreview_Click(object sender, EventArgs e)
        {
            ViewForm vf = CreateViewForm();
            Button fin = vf.Controls.Find("finish", true).FirstOrDefault() as Button;
            vf.Controls.Remove(fin);
            vf.ShowDialog();
            myForm = vf;
            
        }


        private ViewForm CreateViewForm()
        {
         
            ViewForm vf = new ViewForm();
            TextBox questTitle = new TextBox();
            questTitle.ReadOnly = true;
            vf.Size = this.Size;
            // vf.Width = 2000;
            //vf.Height = 4000;
            //Panel setUp = this.Controls.Find("pBanner", true).FirstOrDefault() as Panel;
            Panel setUp = pBanner;
            FlowLayoutPanel header = new FlowLayoutPanel();
            header.BackColor = setUp.BackColor;
            header.ForeColor = setUp.ForeColor;
            header.Anchor = setUp.Anchor;
            header.Size = setUp.Size;
            header.BorderStyle = BorderStyle.Fixed3D;
            header.Dock = DockStyle.Top;
            //header.Location = setUp.Location;





            //=======================
            questTitle.Text = txtTitle.Text;
            questTitle.Font = txtTitle.Font;
            questTitle.Location = txtTitle.Location;
            questTitle.Anchor = txtTitle.Anchor;
            questTitle.BorderStyle = BorderStyle.None;
            questTitle.BackColor = setUp.BackColor;
            questTitle.ForeColor = txtTitle.ForeColor;
            questTitle.Size = txtTitle.Size;
            questTitle.AutoSize = true;
            questTitle.TextAlign = txtTitle.TextAlign;

            //questTitle.Dock = DockStyle.Fill;
            //questTitle.WordWrap = true;

            //=========================

            header.Controls.Add(questTitle);
            setUp = flpMainForm;
            FlowLayoutPanel body = new FlowLayoutPanel();
            body.FlowDirection = FlowDirection.TopDown;
            body.WrapContents = false;
            body.BackColor = setUp.BackColor;
            body.ForeColor = setUp.ForeColor;
            body.Location = new Point(0, header.Height);
            body.Margin = setUp.Margin;
            //body.Anchor = setUp.Anchor;
            //body.AutoSize = true;
            // body.Size = setUp.Size;
            body.Width = header.Width;
            body.AutoScroll = true;
            body.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            body.Dock = DockStyle.Fill;
            
            //============================
            int i = 0;
            foreach (Control c in flpMainForm.Controls)
            {
                Panel1 editPanel = c.Controls[0] as Panel1;
                TextBox qlbl = GetQuestionTitle(setUp, i, editPanel);
                //======================================
                body.Controls.Add(qlbl);
                FlowLayoutPanel flp = new FlowLayoutPanel();
                FlowLayoutPanel copyFrom = editPanel.Controls.Find("flpResponse", true).FirstOrDefault() as FlowLayoutPanel;
                flp.FlowDirection = copyFrom.FlowDirection;
                flp.WrapContents = copyFrom.WrapContents;
                flp.Font = copyFrom.Font;
                flp.BorderStyle = copyFrom.BorderStyle;
                flp.Anchor = copyFrom.Anchor;
                flp.AutoSize = true;
                flp.MinimumSize = new Size(header.Size.Width, 0);
                flp.Name = copyFrom.Name;


                //FlowLayoutPanel buttonsPanel = new FlowLayoutPanel();
                //buttonsPanel.FlowDirection = copyFrom.FlowDirection;
                //buttonsPanel.AutoSize = false;
                //buttonsPanel.Size = copyFrom.Size;
                //buttonsPanel.Anchor = copyFrom.Anchor;
                //buttonsPanel.WrapContents = copyFrom.WrapContents;
                //buttonsPanel.Dock = DockStyle.Bottom;


                flp.AutoSizeMode = AutoSizeMode.GrowAndShrink;
                flp.Location = new Point(10, currentY);
                currentY = currentY + flp.Height + 30;
                if (copyFrom.Controls.Count > 0)
                {
                    foreach (Control box in copyFrom.Controls)
                    {
                        if (box is CheckBox)
                        {
                            CheckBox copyTo = new CheckBox();
                            CheckBox boxFrom = box as CheckBox;
                            //Util.CopyPropertiesTo(box, copyTo);
                            copyTo.Anchor = box.Anchor;
                            copyTo.AutoSize = boxFrom.AutoSize;
                            copyTo.Location = boxFrom.Location;
                            copyTo.Text = boxFrom.Text;
                            copyTo.Font = boxFrom.Font;
                            copyTo.Checked = boxFrom.Checked;
                            copyTo.CheckAlign = boxFrom.CheckAlign;
                            // buttonsPanel.Controls.Add(copyTo);
                            flp.Controls.Add(copyTo);

                        }
                        else if (box is RadioButton)
                        {
                            RadioButton copyTo = new RadioButton();
                            RadioButton boxFrom = box as RadioButton;

                            //Util.CopyPropertiesTo(box, copyTo);

                            copyTo.Anchor = box.Anchor;
                            copyTo.AutoSize = boxFrom.AutoSize;
                            copyTo.Location = boxFrom.Location;
                            copyTo.Text = boxFrom.Text;
                            copyTo.Font = boxFrom.Font;
                            copyTo.Checked = boxFrom.Checked;
                            copyTo.CheckAlign = boxFrom.CheckAlign;
                            flp.Controls.Add(copyTo);
                        }
                        else if (box is Questionary.LikertUnit)
                        {
                            LikertUnit copyto = new LikertUnit();
                            LikertUnit copyFromBox = (LikertUnit)box;

                            GroupBox gb = new GroupBox();
                            copyto.boxText = copyFromBox.boxText;
                            copyto.Anchor = copyFromBox.Anchor;
                            copyto.Size = copyFromBox.Size;
                            copyto.BorderStyle = BorderStyle.None;//copyFrom.BorderStyle;
                            copyto.boxEdit = true;

                            flp.Controls.Add(copyto);

                            //TODO: enable add/remove borders on Likert values.
                        }
                        else if (box is LineControl)
                        {
                            LineControl copyTo = new LineControl();
                            LineControl copyFromBox = box as LineControl;
                            copyTo.Size = box.Size;
                            copyTo.Font = box.Font;
                            copyTo.Text = copyFromBox.Text;
                            flp.Controls.Add(copyTo);
                        }
                        else if (box is TextBox)
                        {
                            TextBox copyTo = new TextBox();
                            TextBox copyFromBox = box as TextBox;
                            copyTo.Size = box.Size;
                            copyTo.Text = box.Text;
                            copyTo.TextAlign = copyFromBox.TextAlign;
                            copyTo.Font = box.Font;
                            copyTo.ForeColor = box.ForeColor;
                            copyTo.BackColor = box.BackColor;
                            flp.Controls.Add(copyTo);
                        }
                        else if (box is RichTextBox)
                        {
                            RichTextBox copyTo = new RichTextBox();
                            RichTextBox copyFromBox = box as RichTextBox;
                            if (!box.Name.Contains("rbx"))
                            {
                                copyTo.Size = box.Size;
                                copyTo.Text = box.Text;
                                copyTo.Font = box.Font;
                                copyTo.ForeColor = box.ForeColor;
                                copyTo.BackColor = box.BackColor;
                                flp.Controls.Add(copyTo);
                            }
                        }
                        else if (box is DateTimePicker)
                        {
                            DateTimePicker copyTo = new DateTimePicker();
                            DateTimePicker copyFromBox = box as DateTimePicker;
                            copyTo.Size = box.Size;
                            copyTo.Text = box.Text;
                            copyTo.Font = box.Font;
                            copyTo.ForeColor = box.ForeColor;
                            copyTo.BackColor = box.BackColor;
                            flp.Controls.Add(copyTo);
                        }
                        else if (box is ComboBox)
                        {
                            ComboBox copyTo = new ComboBox();
                            ComboBox copyFromBox = box as ComboBox;
                            copyTo.DropDownStyle = copyFromBox.DropDownStyle;
                            
                            copyTo.Width = copyFromBox.DropDownWidth;
                            //Graphics g = copyTo.CreateGraphics();
                            Font font = copyTo.Font;
                            foreach (string item in copyFromBox.Items)
                            {
                                copyTo.Items.Add(item);
                             
                            }
                       
                            flp.Controls.Add(copyTo);
                        }
                        else if (box is TextFormatQuest)
                        {
                            TextFormatQuest copyFromT = box as TextFormatQuest;
                            string text = copyFromT.Controls.Find("rtbText", true).FirstOrDefault().Text;
                            Button btn = new Button();
                            btn.Text = "Show Text";
                            //btn.Click += new System.EventHandler(btn_Click);
                            btn.Click+=new EventHandler((s, e) => btn_Click(s, e, text));
                            flp.Controls.Add(btn);
                        }
                    }
                }

                //flp.Controls.Add(buttonsPanel);
                body.Controls.Add(flp);
                i++;
            }

            Panel center = vf.Controls.Find("center", true).FirstOrDefault() as Panel;
            center.Controls.Add(body);
            vf.Controls.Add(header);
            vf.Padding = new Padding(10);

            return vf;
        }

        private void btn_Click(object sender, EventArgs e, string text)
        {
            TextQuest tq = new TextQuest();
            tq.Text = text;
            tq.Show();
        }

        private void Save(ViewForm vf)
        {

            CustomForm form = new CustomForm();           
            form.ThisForm = this.Size;
            form.Header = new CustomForm.FormHeader();
            form.Header.ExportSettings = new ExportSettings();
            form.Header.ExportSettings.AnswersFormat = _answersFormat;
            form.Header.ExportSettings.QuestionsId = _questionsId;
            form.Header.Settings = new CommonSettings();
            form.Header.Settings.BackColor = pBanner.BackColor.Name;
            form.Header.Settings.ForeColor = pBanner.ForeColor.Name;
            form.Header.Settings.Test = pBanner.ForeColor.ToArgb();
            form.Header.Settings.Anchor = pBanner.Anchor;
            form.Header.Settings.Size = pBanner.Size;
            form.Header.HeaderTextString = new CustomForm.FormHeader.HeaderText();
            form.Header.HeaderTextString.Settings = new CommonSettings();
            form.Header.HeaderTextString.Settings.TextValue = txtTitle.Text;
            form.Header.HeaderTextString.Settings.font = new SeriFont();
            form.Header.HeaderTextString.Settings.font.FontFamily = txtTitle.Font.FontFamily.ToString();
            form.Header.HeaderTextString.Settings.font.Size = txtTitle.Font.Size;
            form.Header.HeaderTextString.Settings.font.Style = txtTitle.Font.Style;
            //form.Header.HeaderTextString.Settings.font.GraphicsUnit = GraphicsUnit.World;
            form.Header.HeaderTextString.Settings.Location = txtTitle.Location;
            form.Header.HeaderTextString.Settings.Anchor = txtTitle.Anchor;
            form.Header.HeaderTextString.Settings.BorderStyle = BorderStyle.None;
            form.Header.HeaderTextString.Settings.ForeColor = txtTitle.ForeColor.Name;
            form.Header.HeaderTextString.Settings.BackColor = txtTitle.BackColor.Name;
            form.Header.HeaderTextString.Settings.Size = txtTitle.Size;
            form.Header.HeaderTextString.Settings.AutoSize = true;
            form.Header.HeaderTextString.Settings.TextAlign = txtTitle.TextAlign;

            //====================================================================Header
            form.FormBody = new CustomForm.Body();
            form.FormBody.Settings = new CommonSettings();
            form.FormBody.Settings.FlowDorection = flpMainForm.FlowDirection;
            form.FormBody.Settings.WrapContent = false;
            form.FormBody.Settings.BackColor = flpMainForm.BackColor.Name;
            form.FormBody.Settings.ForeColor = flpMainForm.ForeColor.Name;
            form.FormBody.Settings.font  = new SeriFont();
            form.FormBody.Settings.font.Size = flpMainForm.Font.Size;
            form.FormBody.Settings.font.Style = flpMainForm.Font.Style;
            form.FormBody.Settings.font.FontFamily = flpMainForm.Font.FontFamily.ToString();

            form.FormBody.Settings.Size = flpMainForm.Size;
            form.FormBody.Settings.AutoScroll = true;
            int i = 0;
            form.FormBody.Responses = new List<CustomForm.Body.Response>();
            foreach (Control c in flpMainForm.Controls)
            {
                form.FormBody.QuestResponse = new CustomForm.Body.Response();
                //form.FormBody.QuestResponse.Control = new CustomForm.Body.Response.MyControl();
                form.FormBody.QuestResponse.QuestionNumber = i;
                form.FormBody.QuestResponse.Settings = new CommonSettings();
                form.FormBody.QuestResponse.QuestionTitle = new CustomForm.Body.QuestTitle();

                form.FormBody.QuestResponse.QuestionTitle.Settings = new CommonSettings();
                Control editPanel = c.Controls[0] as Panel1;

                form.FormBody.QuestResponse.QuestVarName = editPanel.Controls.Find("txtVarName", true).FirstOrDefault().Text;
                TextBox copyFrom = editPanel.Controls.Find("txtQuestionText", true).FirstOrDefault() as TextBox;
                if (copyFrom == null)
                {
                    copyFrom = editPanel.Controls.Find("BlockHeader", true).FirstOrDefault() as TextBox;
                }
                CheckBox cb = editPanel.Controls.Find("cbRequired", true).FirstOrDefault() as CheckBox;
                if (cb.Checked)
                    form.FormBody.QuestResponse.Required = true;
                form.FormBody.QuestResponse.QuestionTitle = new CustomForm.Body.QuestTitle();
                form.FormBody.QuestResponse.QuestionTitle.Settings = new CommonSettings();
                form.FormBody.QuestResponse.QuestionTitle.Settings.TextValue = copyFrom.Text;
                form.FormBody.QuestResponse.QuestionTitle.Settings.font = new SeriFont();
                form.FormBody.QuestResponse.QuestionTitle.Settings.font.FontFamily = copyFrom.Font.FontFamily.Name;
                form.FormBody.QuestResponse.QuestionTitle.Settings.font.Size = copyFrom.Font.Size;
                form.FormBody.QuestResponse.QuestionTitle.Settings.font.Style = copyFrom.Font.Style;
                form.FormBody.QuestResponse.QuestionTitle.Settings.TextAlign = copyFrom.TextAlign;
                form.FormBody.QuestResponse.QuestionTitle.Settings.Anchor = copyFrom.Anchor;
                form.FormBody.QuestResponse.QuestionTitle.Settings.AutoSize = true;
                form.FormBody.QuestResponse.QuestionTitle.Settings.BorderStyle = BorderStyle.None;
                form.FormBody.QuestResponse.QuestionTitle.Settings.BackColor = c.BackColor.Name;
                form.FormBody.QuestResponse.QuestionTitle.Settings.Size = copyFrom.Size;
                form.FormBody.QuestResponse.QuestionTitle.Settings.AutoSizeMode = AutoSizeMode.GrowAndShrink;
                FlowLayoutPanel copyFromp = editPanel.Controls.Find("flpResponse", true).FirstOrDefault() as FlowLayoutPanel;
                form.FormBody.QuestResponse.Settings.FlowDorection = copyFromp.FlowDirection;
                form.FormBody.QuestResponse.Settings.WrapContent = copyFromp.WrapContents;
                form.FormBody.QuestResponse.Settings.font = new SeriFont();
                form.FormBody.QuestResponse.Settings.font.FontFamily = copyFromp.Font.FontFamily.Name;
                form.FormBody.QuestResponse.Settings.font.Size = copyFromp.Font.Size;
                form.FormBody.QuestResponse.Settings.font.Style = copyFromp.Font.Style;
                form.FormBody.QuestResponse.Settings.BorderStyle = copyFromp.BorderStyle;
                form.FormBody.QuestResponse.Settings.Anchor = copyFromp.Anchor;
                form.FormBody.QuestResponse.Settings.AutoSize = copyFromp.AutoSize;
                form.FormBody.QuestResponse.Settings.AutoSizeMode = AutoSizeMode.GrowAndShrink;

                form.FormBody.QuestResponse.Controls = new List<CustomForm.Body.Response.MyControl>();

                //TODO: check for nulls;  
                foreach (Control box in copyFromp.Controls)
                {

                    if (box is CheckBox)
                    {
                        CheckBox boxFrom = box as CheckBox;
                        form.FormBody.QuestResponse.Type = "checkbox";
                        form.FormBody.QuestResponse.Controls.Add(new CustomForm.Body.Response.MyControl
                        {
                            Type = "checkbox",
                            isChecked = boxFrom.Checked,
                            CheckAlign = boxFrom.CheckAlign,
                            Settings = new CommonSettings
                            {
                                Anchor = box.Anchor,
                                AutoSize = boxFrom.AutoSize,
                                TextValue = boxFrom.Text,
                                font = new SeriFont
                                {
                                    Style = boxFrom.Font.Style,
                                    Size = boxFrom.Font.Size,
                                    FontFamily = box.Font.FontFamily.Name
                                }
                            }
                        });
                    }
                    else if (box is RadioButton)
                    {
                        RadioButton boxFrom = box as RadioButton;
                        form.FormBody.QuestResponse.Type = "Radio";
                        form.FormBody.QuestResponse.Controls.Add(new CustomForm.Body.Response.MyControl
                        {
                            Type = "radio",
                            isChecked = boxFrom.Checked,
                            CheckAlign = boxFrom.CheckAlign,
                            Settings = new CommonSettings
                            {
                                Anchor = box.Anchor,
                                AutoSize = boxFrom.AutoSize,
                                TextValue = boxFrom.Text,
                                font = new SeriFont
                                {
                                    Style = boxFrom.Font.Style,
                                    Size = boxFrom.Font.Size,
                                    FontFamily = box.Font.FontFamily.Name
                                }
                            }
                        });
                    }
                    else if (box is DateTimePicker)
                    {
                        form.FormBody.QuestResponse.Type = "DateTime";
                        form.FormBody.QuestResponse.Controls.Add(new CustomForm.Body.Response.MyControl
                        {
                            Type = "DateTime",
                            CheckAlign = ContentAlignment.TopRight
                        });
                    }

                    else if (box is LikertUnit)
                    {
                        LikertUnit copyFromBox = (LikertUnit)box;
                        form.FormBody.QuestResponse.Type = "Likert";
                        form.FormBody.QuestResponse.Controls.Add(new CustomForm.Body.Response.MyControl
                        {
                            Type = "Likert",
                            CheckAlign = ContentAlignment.TopRight,
                            Settings = new CommonSettings
                            {
                                TextValue = copyFromBox.boxText,
                                Anchor = copyFromBox.Anchor,
                                Size = copyFromBox.Size,
                                TextAlign = HorizontalAlignment.Center,
                                font = new SeriFont
                                {
                                    Size = copyFromBox.Font.Size,
                                    FontFamily = copyFromBox.Font.FontFamily.Name,
                                    Style = copyFromBox.Font.Style
                                }
                                //BorderStyle = copyFromBox.BorderStyle,

                            }

                        });

                    }
                    else if (box is TextBox)
                    {
                        TextBox copyFromBox = box as TextBox;
                        form.FormBody.QuestResponse.Type = "TextBox";
                        form.FormBody.QuestResponse.Controls.Add(new CustomForm.Body.Response.MyControl
                        {
                            CheckAlign = ContentAlignment.TopRight,
                            Type = "TextBox",
                            Settings = new CommonSettings
                            {
                                Size = copyFrom.Size,
                                TextValue = copyFromBox.Text,
                                ForeColor = copyFromBox.ForeColor.Name,
                                BackColor = copyFromBox.BackColor.Name,
                                font = new SeriFont
                                {
                                    Size = copyFromBox.Font.Size,
                                    FontFamily = copyFromBox.Font.FontFamily.Name,
                                    Style = copyFromBox.Font.Style
                                }
                            }
                        });
                    }
                    else if (box is LineControl)
                    {
                        LineControl copyFromBox = box as LineControl;
                        form.FormBody.QuestResponse.Controls.Add(new CustomForm.Body.Response.MyControl
                        {
                            CheckAlign = ContentAlignment.TopRight,
                            Type = "LineControl",
                            Settings = new CommonSettings
                            {
                                Size = copyFrom.Size,
                                TextValue = copyFromBox.Text,
                                ForeColor = copyFromBox.ForeColor.Name,
                                BackColor = copyFromBox.BackColor.Name,
                                font = new SeriFont
                                {
                                    Size = copyFromBox.Font.Size,
                                    FontFamily = copyFromBox.Font.FontFamily.Name,
                                    Style = copyFromBox.Font.Style
                                }
                            }
                        });


                    }
                    else if (box is RichTextBox && !box.Name.Contains("rbx"))
                    {
                        RichTextBox copyFromBox = box as RichTextBox;
                        form.FormBody.QuestResponse.Type = "RBX";
                        form.FormBody.QuestResponse.Controls.Add(new CustomForm.Body.Response.MyControl
                        {
                            Type = "RichTextBox",
                            CheckAlign = ContentAlignment.TopRight,
                            Settings = new CommonSettings
                            {
                                Size = copyFrom.Size,
                                TextValue = copyFromBox.Text,
                                ForeColor = copyFromBox.ForeColor.Name,
                                BackColor = copyFromBox.BackColor.Name,
                                font = new SeriFont
                                {
                                    Size = copyFromBox.Font.Size,
                                    FontFamily = copyFromBox.Font.FontFamily.Name,
                                    Style = copyFromBox.Font.Style
                                }
                            }
                        });
                    }
                    else if (box is ComboBox)
                    {
                        ComboBox copyFromBox = box as ComboBox;
                        form.FormBody.QuestResponse.Type = "DropDown";
                        List <string> items = new List<string>();
                        foreach (var item in copyFromBox.Items)
                        {
                            items.Add(item.ToString());
                        }
                        form.FormBody.QuestResponse.Controls.Add(new CustomForm.Body.Response.MyControl
                        {
                            Type = "DropDown",
                            CheckAlign = ContentAlignment.TopRight,
                            ItemList = items


                        });

                    }
                    else if (box is BlockHeader)
                    {
                        form.FormBody.QuestResponse.Type = "BlockHeader";
       
                    }
                    else if (box is TextFormatQuest)
                    {
                        TextFormatQuest tq = box as TextFormatQuest;
                        form.FormBody.QuestResponse.Type = "TextFormatQuest";
                        form.FormBody.QuestResponse.Settings.TextValue = tq.Controls.Find("rtbText", true).FirstOrDefault().Text;
                    }
                }
                form.FormBody.Responses.Add(form.FormBody.QuestResponse);
            }

            SaveFileName sf = new SaveFileName(form);

            sf.ShowDialog();
            sf.Dispose();




        }
        //=========================Make Title repositioned==============
        //private Point FindLocation(Control ctrl)
        //{
        //    if (ctrl.Parent is Form)
        //        return ctrl.Location;
        //    else
        //    {
        //        Point p = FindLocation(ctrl.Parent);
        //        p.X += ctrl.Location.X;
        //        p.Y += ctrl.Location.Y;
        //        return p;
        //    }
        //}

        //private void txtTitle_MouseMove(object sender, MouseEventArgs e)
        //{
        //    if (e.Button == MouseButtons.Left)
        //    {
        //        txtTitle.Left += e.X - move.X;
        //        txtTitle.Top = e.Y - move.Y;
        //    }
        //}

        //private void txtTitle_MouseDown(object sender, MouseEventArgs e)
        //{
        //    move = e.Location;
        //}

        private void textToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Panel1 pText = new Panel1(i, "TextBox");
        }

        #region
        //===========================Add/Delete Question Panel============================
        private void addQuestionToolStripMenuItem_Click(object sender, EventArgs e)
        {

            //TODO: figure this out;
        }

        private void deleteQuestionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var test = e;
            var s = sender as ToolStripMenuItem;
            string nameToFind = "p" + s.Name;
            flpMainForm.Controls.Remove(flpMainForm.Controls.Find(nameToFind, true).FirstOrDefault() as Panel);
            i--;

        }


        private MenuStrip CreateMenuStrip(int panel)
        {
            MenuStrip addDeleteQuestion = new MenuStrip();
            var addQuestionToolStripMenuItem = new ToolStripMenuItem();
            var deleteQuestionToolStripMenuItem = new ToolStripMenuItem();
            //addDeleteQuestion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            addDeleteQuestion.Dock = System.Windows.Forms.DockStyle.Bottom;
            addDeleteQuestion.ImageScalingSize = new System.Drawing.Size(24, 24);
            addDeleteQuestion.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { addQuestionToolStripMenuItem, deleteQuestionToolStripMenuItem });
            addDeleteQuestion.Location = new System.Drawing.Point(419, 229);
            addDeleteQuestion.Name = panel.ToString();
            addDeleteQuestion.Size = new System.Drawing.Size(432, 33);
            addDeleteQuestion.TabIndex = 9;
            addDeleteQuestion.Text = "menuStrip1";
            // 
            // addQuestionToolStripMenuItem
            //// 
            //addQuestionToolStripMenuItem.Name = panel.ToString();
            //addQuestionToolStripMenuItem.Size = new System.Drawing.Size(135, 29);
            //addQuestionToolStripMenuItem.Text = "Add Question";
            //addQuestionToolStripMenuItem.Click += new System.EventHandler(addQuestionToolStripMenuItem_Click);
            // 
            // deleteQuestionToolStripMenuItem
            // 
            deleteQuestionToolStripMenuItem.Name = panel.ToString();
            deleteQuestionToolStripMenuItem.Size = new System.Drawing.Size(151, 29);
            deleteQuestionToolStripMenuItem.Text = "Delete Question";
            deleteQuestionToolStripMenuItem.Click += new System.EventHandler(deleteQuestionToolStripMenuItem_Click);

            return addDeleteQuestion;

        }
        #endregion
        #region 
        //--------------------Create Response Type Controls-------------------

        //====================== multi options=========================
        private void multiChoiceToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            string txt = e.ClickedItem.Text;
            Panel1 p1 = new Panel1(i, txt);
            CreatePanel(p1);
        }



        //===================Text =========================

        //TODO: refactor this shit
        //===========Likert==============================
        private void likertToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Panel1 p1 = new Panel1(i, "Likert");
            CreatePanel(p1);
        }

        #endregion

        //================Create Question Panel Method======================================= //TODO:Panel is too large
        public void CreatePanel(Panel1 p1)
        {
            p1.Name = "p" + i;
            Panel p = new Panel();
            p.BorderStyle = BorderStyle.Fixed3D;
           
            p.Size = new Size(Screen.PrimaryScreen.Bounds.Width-30, p1.Height + 33);
            p.Name = "p" + i;
            flpMainForm.Controls.Add(p);
            p.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            p1.Anchor = AnchorStyles.Right | AnchorStyles.Left | AnchorStyles.Top;
            p1.Width = p.Width;
            p.AutoScroll = true;
            MenuStrip menu = CreateMenuStrip(i);
            p1.Controls.Add(menu);
            p.Controls.Add(p1);
            p1.Parent = p;
            i++;
        }


        private static TextBox GetQuestionTitle(Panel setUp, int i, Panel1 editPanel)
        {
            if (i == 0)
            {
                currentY = 0;
            }
            TextBox qlbl = new TextBox();
            qlbl.Name = i.ToString();
            //currentY = qlbl.Location.Y + qlbl.Height + 30;
            TextBox copyFrom = editPanel.Controls.Find("txtQuestionText", true).FirstOrDefault() as TextBox;
            if (copyFrom == null)
            {
                copyFrom = editPanel.Controls.Find("BlockHeader", true).FirstOrDefault() as TextBox;
            }
            qlbl.Text = copyFrom.Text;
            CheckBox cb = editPanel.Controls.Find("cbRequired", true).FirstOrDefault() as CheckBox;
            if (cb.Checked)
            {
                qlbl.Text += "(*)";
            }
           
            qlbl.Font = copyFrom.Font;
            qlbl.ReadOnly = true;
            qlbl.Cursor = Cursors.No;
            qlbl.SelectionLength = 0;
            qlbl.TextAlign = copyFrom.TextAlign;
            qlbl.Anchor = copyFrom.Anchor;
            qlbl.Width = qlbl.Text.Length + 2;
            //qlbl.AutoSize = true;
            qlbl.BorderStyle = BorderStyle.None;
            qlbl.BackColor = setUp.BackColor;
            //qlbl.Size = copyFrom.Size;
            qlbl.Multiline = true;
            qlbl.WordWrap = true;

            return qlbl;
        }

        //=======================Print=================================
        #region 
        private void printButton_Click(object sender, EventArgs e)
        {

            PrintDialog printDlg = new PrintDialog();
            PrintDocument printDoc = new PrintDocument();
            printDoc.DocumentName = "Print Document";
            printDlg.Document = printDoc;
            printDlg.AllowSelection = true;
            printDlg.AllowSomePages = true;
            PaperSize ps = new PaperSize();
            ps.RawKind = (int)PaperKind.A4;
     


            //Call ShowDialog
            if (printDlg.ShowDialog() == DialogResult.OK)
            {


                CaptureScreen();
            }

          
        }

        //void printButton_Click(object sender, EventArgs e)
        //{
        //    //ViewForm vf = new ViewForm();
        //    //vf = CreateViewForm();
        //    //vf.FormBorderStyle = FormBorderStyle.None;
        //    //vf.StartPosition = FormStartPosition.CenterScreen;

        //    //vf.Show();
        //    CaptureScreen();
        //    printDocument1.Print();
        //}

        Bitmap memoryImage;
        private void CaptureScreen()
        {
            Graphics myGraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, myGraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            memoryGraphics.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, s);

        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            ViewForm vf = CreateViewForm();
            var createControl = vf.GetType().GetMethod("CreateControl",
                BindingFlags.Instance | BindingFlags.NonPublic);
            createControl.Invoke(vf, new object[] { true });
            Bitmap image = new Bitmap(vf.Width, vf.Height);
            DrawToBitmap(image, new Rectangle(new Point(0, 0), image.Size));
            image.Save(Application.StartupPath + @"\testtest.bmp", System.Drawing.Imaging.ImageFormat.Jpeg);


            //e.Graphics.DrawImage(memoryImage, e.PageBounds);
            //    ViewForm vf = new ViewForm();
            //    vf = CreateViewForm();
            //    vf.FormBorderStyle = FormBorderStyle.None;
            //    vf.StartPosition = FormStartPosition.CenterScreen;
            //    //vf.ShowDialog();
            //    int x = SystemInformation.WorkingArea.X;
            //    int y = SystemInformation.WorkingArea.Y;

            //    int width = vf.Width;
            //    int height = vf.Height;
            //    Rectangle bounds = new Rectangle(x, y, width, height);
            //    Bitmap i = new Bitmap(width, height);
            //    this.DrawToBitmap(i, bounds);


            //    float newWidth = i.Width * 100 / i.HorizontalResolution;
            //    float newHeight = i.Height * 100 / i.VerticalResolution;

            //    float widthFactor = newWidth / e.PageBounds.Width;
            //    float heightFactor = newHeight / e.PageBounds.Height;

            //    if (widthFactor > 1 | heightFactor > 1)
            //    {
            //        if (widthFactor > heightFactor)
            //        {
            //            newWidth = newWidth / widthFactor;
            //            newHeight = newHeight / widthFactor;
            //        }
            //        else
            //        {
            //            newWidth = newWidth / heightFactor;
            //            newHeight = newHeight / heightFactor;
            //        }
            //    }
            //    e.Graphics.DrawImage(i, 0, 0, (int)newWidth, (int)newHeight);
            //    i.Save(Application.StartupPath + @"\testtest.bmp", ImageFormat.Jpeg);
        }
        #endregion

        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewForm vf = CreateViewForm();
            var createControl = vf.GetType().GetMethod("CreateControl",
                BindingFlags.Instance | BindingFlags.NonPublic);
            createControl.Invoke(vf, new object[] { true });
            Bitmap image = new Bitmap(vf.Width, vf.Height);
            vf.DrawToBitmap(image, new Rectangle(new Point(0, 0), image.Size));
            image.Save(Application.StartupPath + @"\hoo.bmp", System.Drawing.Imaging.ImageFormat.Jpeg);
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewForm vf = CreateViewForm();
            //vf.ShowDialog();
            myForm = vf;
            Save(myForm);
        }

        private void showColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(pBanner.BackColor.Name);
        }

        private void greenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pBanner.BackColor = Color.Green;
        }

        private void purpleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pBanner.BackColor = Color.Purple;
        }

        private void yellowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pBanner.BackColor = Color.Yellow;
        }

        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pBanner.BackColor = Color.LightCoral;

        }

        private void brownToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pBanner.BackColor = Color.RosyBrown;
        }


        private void textToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            string txt = e.ClickedItem.Text;
            Panel1 p1 = new Panel1(i, txt);
            CreatePanel(p1);

        }

        private void dateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Panel1 p1 = new Panel1(i, "DateTime");
            CreatePanel(p1);
        }

        private void dropDownboxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Panel1 p1 = new Panel1(i, "DropDown");
            CreatePanel(p1);
        }

        private void greenToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            flpMainForm.BackColor = Color.Honeydew;
        }

        private void yelloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            flpMainForm.BackColor = Color.LemonChiffon;
        }

        private void redToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            flpMainForm.BackColor = Color.Pink;
        }

        private void purpleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            flpMainForm.BackColor = Color.LavenderBlush;
        }

        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            flpMainForm.BackColor = Color.Azure;
        }

        private void headerFontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {
                txtTitle.Font = fd.Font;

            }
        }

        private void whiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            flpMainForm.BackColor = Color.White;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            // Confirm user wants to close
            switch (MessageBox.Show(this, "Are you sure you want to close?", "Close Form", MessageBoxButtons.YesNo))
            {
                case DialogResult.No:
                    e.Cancel = true;
                    break;
                default:
                    break;
            }
        }

        private void blockHeaderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            Panel1 p1 = new Panel1(i, "header");
            CreatePanel(p1);
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //base.OnFormClosing(e);

            //if (e.CloseReason == CloseReason.WindowsShutDown) return;

            //// Confirm user wants to close
            //switch (MessageBox.Show(this, "Are you sure you want to close?", "Close Form", MessageBoxButtons.YesNo))
            //{
            //    case DialogResult.No:
            //        e.Cancel = true;
            //        break;
            //    default:
            //        break;
            //}

            this.Close();
        }

        private void textFormQuestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Panel1 p1 = new Panel1(i, "textFormQuest");
            CreatePanel(p1);
        }
    }
}

