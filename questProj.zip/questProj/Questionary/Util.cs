﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Questionary
{
    static class Util
    {
        public static void CopyPropertiesTo<T, TU>(this T source, TU dest)
        {

            var sourceProps = typeof(T).GetProperties().Where(x => x.CanRead).ToList();
            var destProps = typeof(TU).GetProperties()
                    .Where(x => x.CanWrite)
                    .ToList();

            foreach (var sourceProp in sourceProps)
            {
                if (destProps.Any(x => x.Name == sourceProp.Name))
                {
                    var p = destProps.First(x => x.Name == sourceProp.Name);
                    p.SetValue(dest, sourceProp.GetValue(source, null), null);
                }

            }

        }
        public static BorderStyle MapBorderStyle(string txt)
        {
            BorderStyle style = new BorderStyle();
            switch (txt)
            {
                case "Single":
                    style = BorderStyle.FixedSingle;
                    break;
                case "None":
                    style = BorderStyle.None;
                    break;
                case "Single 3D":
                    style = BorderStyle.Fixed3D;
                    break;
            }
            return style;
        }

        public static HorizontalAlignment MapTextAlign(string txt)
        {
            HorizontalAlignment align = new HorizontalAlignment();
            switch (txt)
            {
                case "Right":
                    align = HorizontalAlignment.Right;
                    break;
                case "Left":
                    align = HorizontalAlignment.Left;
                    break;
                case "Center":
                    align = HorizontalAlignment.Center;
                    break;
            }
            return align;

        }

        public static FontStyle MapFontStyle (string txt)
        {
            FontStyle style = new FontStyle();
            switch (txt)
            {
                case "Bold":
                    style = FontStyle.Bold;
                    break;
                case "Italic":
                    style = FontStyle.Italic;
                    break;
                case "Bold italic":
                  style = FontStyle.Italic | FontStyle.Bold;
                    break;
                default:
                   style = FontStyle.Regular;
                    break;
            }
            return style;

        }

        public static FlowDirection MapFlowDirection (string txt)
        {
            FlowDirection fd = new FlowDirection();
            switch (txt)
            {
                case "Bottom Up":
                fd = FlowDirection.BottomUp;
                    break;
                case "Right To Left":
                    fd = FlowDirection.RightToLeft;
                    break;
                case "Left To Right":
                   fd = FlowDirection.LeftToRight;
                    break;
                case "Top Down":
                    fd = FlowDirection.TopDown;
                    break;
            }
            return fd;
        }
            

    }
}
