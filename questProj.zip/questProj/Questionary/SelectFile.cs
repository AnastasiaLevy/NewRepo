﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Questionary.Services;


namespace Questionary
{
    public partial class SelectFile : Form

    {
        public string Reason;
        public SelectFile(string reason)
        {
            InitializeComponent();
            Reason = reason;
            label1.BackColor = Color.Transparent;

            string[] array1 = new DirectoryInfo(Application.StartupPath + "\\tests").GetFiles().Select(o => o.Name).ToArray();
            foreach (string s in array1)
            {
                Button bt = new Button();
                bt.Text = s.Replace(".xml", "");
                bt.Name = s;
                bt.BackColor = Color.LightBlue;

                bt.Click += new EventHandler(NewButton_Click);
                fileList.Controls.Add(bt);

            }
        }

        private void NewButton_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (Reason == "edit")
            {
                LoadFromXML.LoadForEdit(btn.Text + ".xml");
            }
            else if (Reason == "start")
            {
                LoadFromXML.ReadProps(btn.Text + ".xml");
            }
            else if (Reason == "export")
            {
                ExportFile(btn.Text);
            }

            else if (Reason == "delete")
            {
                DeleteFile(btn.Text);
            }
            else if (Reason == "exportToHTML")
            {
                ExportHTMLFile(btn.Text);
            }
            this.Close();
            //CreateScoreMap.ReadProps(btn.Text);

        }

        private void DeleteFile(string text)
        {
            //OpenFileDialog fd = new OpenFileDialog();
            //if (fd.ShowDialog() == DialogResult.OK)
            //{
            //    string name = fd.FileName;
            //    string path = Path.GetFullPath(fd.FileName);
            //    File.Delete(name);
            //}
            string sourcePath = Application.StartupPath + "\\tests";
            string sourceFile = System.IO.Path.Combine(sourcePath, text + ".xml");
            try { 
            File.Delete(sourceFile);
            }
            catch (Exception ex)
            {
                MessageBox.Show("File has wrong extention", "Error",
                          MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportFile(string text)
        {
            string sourcePath = Application.StartupPath + "\\tests";
            string sourceFile = System.IO.Path.Combine(sourcePath, text + ".xml");
            SaveFileDialog save = new SaveFileDialog();
            save.FileName = text + ".xml";
            if (save.ShowDialog() == DialogResult.OK)
            {
                string destFile = System.IO.Path.Combine(Path.GetFullPath(save.FileName), save.FileName);
               
                System.IO.File.Copy(sourceFile, destFile, true);
            }
        }

        private void ExportHTMLFile(string text)
        {
            string sourcePath = Application.StartupPath + "\\tests";
            string sourceFile = System.IO.Path.Combine(sourcePath, text + ".xml");
            var converter = new ConverterService(new Serializer());
            var content = converter.HTMLCreator(sourceFile);
            SaveFileDialog save = new SaveFileDialog();
            save.FileName = text + ".html";
            if (save.ShowDialog() == DialogResult.OK)
            {
                string destFile = Path.Combine(Path.GetFullPath(save.FileName), save.FileName);
                File.WriteAllText(destFile, content);
            }
                       
        }
    }
}
