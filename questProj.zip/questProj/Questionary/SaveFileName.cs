﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;

namespace Questionary
{
    public partial class SaveFileName : Form
    {
       // private string filename;

        public string SetFilName
        {
            get { return file.Text; }
            set { file.Text = value; }

        }
        CustomForm _form;
        public SaveFileName(CustomForm form)
        {
            InitializeComponent();
            label1.BackColor = Color.Transparent;
            error.BackColor = Color.Transparent;
            _form = form;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool save = true;
            if (FileExists(file.Text))
            {
                DialogResult result = MessageBox.Show("File this this name already exist. Save?",
                "File exists",
                 MessageBoxButtons.OKCancel);
                if (result == DialogResult.Cancel)
                    save = false;

            }
            if (save)
            {
                try
                {
                    XmlSerializer ser = new XmlSerializer(typeof(CustomForm));
                    XmlWriterSettings ws = new XmlWriterSettings();
                    ws.NewLineHandling = NewLineHandling.Entitize;

                  

                    string fullFilePath = Application.StartupPath + "\\tests" + @"\" + file.Text + ".xml";
                    // string fullFilePath = Application.StartupPath + "\\Templates" + @"\" + file.Text + ".xml";

                    using (XmlWriter wr = XmlWriter.Create(fullFilePath, ws))
                    {
                        ser.Serialize(wr, _form);
                    }

                    //TextWriter writer = new StreamWriter(fullFilePath);
                    //ser.Serialize(writer, _form);
                   // writer.Close();
                    this.Close();


                }
                catch (Exception ex)
                {
                    file.Focus();
                    error.Text = "*The File Name contains illigal characters";

                }
                //   if (ValidateUserText(file.Text) && !FileExists(file.Text))
                //   {
                //       Hide();
                //       SetFilName = file.Text;
                //   }
                //else 
                //   {
                //       file.Focus();
                //       error.Text = "*The File Name contains illigal characters";

                //   }
            }
            else
                file.Text = "";
        }

        private bool FileExists(string text)
        {
            string curFile = Application.StartupPath + "\\tests" + @"\" + file.Text + ".xml";
          
            return (File.Exists(curFile) ? true : false);
        }

        private bool ValidateUserText(string text)
        {
            //true if valid
            //return (!string.IsNullOrEmpty(text) && text.IndexOfAny(System.IO.Path.GetInvalidFileNameChars()) >= 0);
            string sPattern = @"^(?!^(PRN|AUX|CLOCK\$|NUL|CON|COM\d|LPT\d|\..*)(\..+)?$)[^\x00-\x1f\\?*:\"";|/]+$";
         bool value = (Regex.IsMatch(text, sPattern, RegexOptions.CultureInvariant));
            return value;
            //false = not valid;
        }

        private void file_TextChanged(object sender, EventArgs e)
        {
            if (ValidateUserText(file.Text))
            {
                error.Text = "";
            }
        }
    }
}
