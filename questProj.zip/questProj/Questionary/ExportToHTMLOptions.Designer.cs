﻿namespace Questionary
{
    partial class ExportToHTMLOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExportToHTMLOptions));
            this.AnswersFormatBox = new System.Windows.Forms.GroupBox();
            this.TXT = new System.Windows.Forms.RadioButton();
            this.CSV = new System.Windows.Forms.RadioButton();
            this.SelectFormat = new System.Windows.Forms.Label();
            this.QuestionsIdBox = new System.Windows.Forms.GroupBox();
            this.questions = new System.Windows.Forms.RadioButton();
            this.variable = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.Ok = new System.Windows.Forms.Button();
            this.AnswersFormatBox.SuspendLayout();
            this.QuestionsIdBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // AnswersFormatBox
            // 
            this.AnswersFormatBox.Controls.Add(this.TXT);
            this.AnswersFormatBox.Controls.Add(this.CSV);
            this.AnswersFormatBox.Controls.Add(this.SelectFormat);
            this.AnswersFormatBox.Location = new System.Drawing.Point(12, 12);
            this.AnswersFormatBox.Name = "AnswersFormatBox";
            this.AnswersFormatBox.Size = new System.Drawing.Size(220, 84);
            this.AnswersFormatBox.TabIndex = 2;
            this.AnswersFormatBox.TabStop = false;
            this.AnswersFormatBox.Enter += new System.EventHandler(this.AswersFormatBox_Enter);
            // 
            // TXT
            // 
            this.TXT.AutoSize = true;
            this.TXT.Location = new System.Drawing.Point(6, 55);
            this.TXT.Name = "TXT";
            this.TXT.Size = new System.Drawing.Size(46, 17);
            this.TXT.TabIndex = 4;
            this.TXT.TabStop = true;
            this.TXT.Text = "TXT";
            this.TXT.UseVisualStyleBackColor = true;
            // 
            // CSV
            // 
            this.CSV.AutoSize = true;
            this.CSV.Checked = true;
            this.CSV.Location = new System.Drawing.Point(6, 32);
            this.CSV.Name = "CSV";
            this.CSV.Size = new System.Drawing.Size(46, 17);
            this.CSV.TabIndex = 3;
            this.CSV.TabStop = true;
            this.CSV.Text = "CSV";
            this.CSV.UseVisualStyleBackColor = true;
            // 
            // SelectFormat
            // 
            this.SelectFormat.AutoSize = true;
            this.SelectFormat.Location = new System.Drawing.Point(6, 16);
            this.SelectFormat.Name = "SelectFormat";
            this.SelectFormat.Size = new System.Drawing.Size(144, 13);
            this.SelectFormat.TabIndex = 2;
            this.SelectFormat.Text = "Please select answers format";
            // 
            // QuestionsIdBox
            // 
            this.QuestionsIdBox.Controls.Add(this.questions);
            this.QuestionsIdBox.Controls.Add(this.variable);
            this.QuestionsIdBox.Controls.Add(this.label1);
            this.QuestionsIdBox.Location = new System.Drawing.Point(12, 102);
            this.QuestionsIdBox.Name = "QuestionsIdBox";
            this.QuestionsIdBox.Size = new System.Drawing.Size(220, 100);
            this.QuestionsIdBox.TabIndex = 3;
            this.QuestionsIdBox.TabStop = false;
            // 
            // questions
            // 
            this.questions.AutoSize = true;
            this.questions.Location = new System.Drawing.Point(12, 61);
            this.questions.Name = "questions";
            this.questions.Size = new System.Drawing.Size(106, 17);
            this.questions.TabIndex = 2;
            this.questions.TabStop = true;
            this.questions.Text = "Questions names";
            this.questions.UseVisualStyleBackColor = true;
            // 
            // variable
            // 
            this.variable.AutoSize = true;
            this.variable.Checked = true;
            this.variable.Location = new System.Drawing.Point(12, 37);
            this.variable.Name = "variable";
            this.variable.Size = new System.Drawing.Size(97, 17);
            this.variable.TabIndex = 1;
            this.variable.TabStop = true;
            this.variable.Text = "Variable names";
            this.variable.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Use variable names or questions names?";
            // 
            // Ok
            // 
            this.Ok.Location = new System.Drawing.Point(157, 219);
            this.Ok.Name = "Ok";
            this.Ok.Size = new System.Drawing.Size(75, 23);
            this.Ok.TabIndex = 4;
            this.Ok.Text = "Ok";
            this.Ok.UseVisualStyleBackColor = true;
            this.Ok.Click += new System.EventHandler(this.Ok_Click);
            // 
            // ExportToHTMLOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(244, 254);
            this.Controls.Add(this.Ok);
            this.Controls.Add(this.QuestionsIdBox);
            this.Controls.Add(this.AnswersFormatBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ExportToHTMLOptions";
            this.Text = "ExportToHTMLOptions";
            this.AnswersFormatBox.ResumeLayout(false);
            this.AnswersFormatBox.PerformLayout();
            this.QuestionsIdBox.ResumeLayout(false);
            this.QuestionsIdBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox AnswersFormatBox;
        private System.Windows.Forms.RadioButton TXT;
        private System.Windows.Forms.RadioButton CSV;
        private System.Windows.Forms.Label SelectFormat;
        private System.Windows.Forms.GroupBox QuestionsIdBox;
        private System.Windows.Forms.RadioButton questions;
        private System.Windows.Forms.RadioButton variable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Ok;
    }
}