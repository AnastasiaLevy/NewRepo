﻿namespace Questionary
{
    partial class QuestLayout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuestLayout));
            this.pBanner = new System.Windows.Forms.Panel();
            this.colorDialogHeader = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.headerFontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alignTitleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.centerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.greenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purpleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yellowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.brownToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainFormColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backGroundToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.greenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.yelloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.purpleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.blueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.whiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainFormFontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnPreview = new System.Windows.Forms.Button();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.lbQestionnaireName = new System.Windows.Forms.Label();
            this.fileMenu = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.previewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addQuestionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.singleTextBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paragraphToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.likertToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.multiChoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.singleAnswerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.multiAnswerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dropDownboxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blockHeaderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textFormQuestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flpMainForm = new System.Windows.Forms.FlowLayoutPanel();
            this.pBanner.SuspendLayout();
            this.colorDialogHeader.SuspendLayout();
            this.fileMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pBanner
            // 
            this.pBanner.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pBanner.BackColor = System.Drawing.Color.Aquamarine;
            this.pBanner.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pBanner.BackgroundImage")));
            this.pBanner.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pBanner.ContextMenuStrip = this.colorDialogHeader;
            this.pBanner.Controls.Add(this.btnPreview);
            this.pBanner.Controls.Add(this.txtTitle);
            this.pBanner.Controls.Add(this.lbQestionnaireName);
            this.pBanner.Controls.Add(this.fileMenu);
            this.pBanner.Location = new System.Drawing.Point(12, 5);
            this.pBanner.Name = "pBanner";
            this.pBanner.Size = new System.Drawing.Size(954, 162);
            this.pBanner.TabIndex = 0;
            // 
            // colorDialogHeader
            // 
            this.colorDialogHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colorDialogHeader.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.colorDialogHeader.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.headerFontToolStripMenuItem,
            this.alignTitleToolStripMenuItem,
            this.setColorToolStripMenuItem,
            this.mainFormColorToolStripMenuItem,
            this.mainFormFontToolStripMenuItem});
            this.colorDialogHeader.Name = "colorDialogHeader";
            this.colorDialogHeader.Size = new System.Drawing.Size(280, 174);
            // 
            // headerFontToolStripMenuItem
            // 
            this.headerFontToolStripMenuItem.Name = "headerFontToolStripMenuItem";
            this.headerFontToolStripMenuItem.Size = new System.Drawing.Size(279, 34);
            this.headerFontToolStripMenuItem.Text = "Title Font";
            this.headerFontToolStripMenuItem.Click += new System.EventHandler(this.headerFontToolStripMenuItem_Click);
            // 
            // alignTitleToolStripMenuItem
            // 
            this.alignTitleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rightToolStripMenuItem,
            this.leftToolStripMenuItem,
            this.centerToolStripMenuItem});
            this.alignTitleToolStripMenuItem.Name = "alignTitleToolStripMenuItem";
            this.alignTitleToolStripMenuItem.Size = new System.Drawing.Size(279, 34);
            this.alignTitleToolStripMenuItem.Text = "Align Title";
            this.alignTitleToolStripMenuItem.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.alignTitleToolStripMenuItem_DropDownItemClicked);
            // 
            // rightToolStripMenuItem
            // 
            this.rightToolStripMenuItem.Name = "rightToolStripMenuItem";
            this.rightToolStripMenuItem.Size = new System.Drawing.Size(171, 34);
            this.rightToolStripMenuItem.Text = "Right";
            // 
            // leftToolStripMenuItem
            // 
            this.leftToolStripMenuItem.Name = "leftToolStripMenuItem";
            this.leftToolStripMenuItem.Size = new System.Drawing.Size(171, 34);
            this.leftToolStripMenuItem.Text = "Left";
            // 
            // centerToolStripMenuItem
            // 
            this.centerToolStripMenuItem.Name = "centerToolStripMenuItem";
            this.centerToolStripMenuItem.Size = new System.Drawing.Size(171, 34);
            this.centerToolStripMenuItem.Text = "Center";
            // 
            // setColorToolStripMenuItem
            // 
            this.setColorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backgroundToolStripMenuItem});
            this.setColorToolStripMenuItem.Name = "setColorToolStripMenuItem";
            this.setColorToolStripMenuItem.Size = new System.Drawing.Size(279, 34);
            this.setColorToolStripMenuItem.Text = "Header Color";
            // 
            // backgroundToolStripMenuItem
            // 
            this.backgroundToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.greenToolStripMenuItem,
            this.purpleToolStripMenuItem,
            this.yellowToolStripMenuItem,
            this.redToolStripMenuItem,
            this.brownToolStripMenuItem});
            this.backgroundToolStripMenuItem.Name = "backgroundToolStripMenuItem";
            this.backgroundToolStripMenuItem.Size = new System.Drawing.Size(228, 34);
            this.backgroundToolStripMenuItem.Text = "Background";
            // 
            // greenToolStripMenuItem
            // 
            this.greenToolStripMenuItem.BackColor = System.Drawing.Color.ForestGreen;
            this.greenToolStripMenuItem.Name = "greenToolStripMenuItem";
            this.greenToolStripMenuItem.Size = new System.Drawing.Size(173, 34);
            this.greenToolStripMenuItem.Text = "Green";
            this.greenToolStripMenuItem.Click += new System.EventHandler(this.greenToolStripMenuItem_Click);
            // 
            // purpleToolStripMenuItem
            // 
            this.purpleToolStripMenuItem.BackColor = System.Drawing.Color.Fuchsia;
            this.purpleToolStripMenuItem.Name = "purpleToolStripMenuItem";
            this.purpleToolStripMenuItem.Size = new System.Drawing.Size(173, 34);
            this.purpleToolStripMenuItem.Text = "Purple";
            this.purpleToolStripMenuItem.Click += new System.EventHandler(this.purpleToolStripMenuItem_Click);
            // 
            // yellowToolStripMenuItem
            // 
            this.yellowToolStripMenuItem.BackColor = System.Drawing.Color.Yellow;
            this.yellowToolStripMenuItem.Name = "yellowToolStripMenuItem";
            this.yellowToolStripMenuItem.Size = new System.Drawing.Size(173, 34);
            this.yellowToolStripMenuItem.Text = "Yellow";
            this.yellowToolStripMenuItem.Click += new System.EventHandler(this.yellowToolStripMenuItem_Click);
            // 
            // redToolStripMenuItem
            // 
            this.redToolStripMenuItem.BackColor = System.Drawing.Color.LightCoral;
            this.redToolStripMenuItem.Name = "redToolStripMenuItem";
            this.redToolStripMenuItem.Size = new System.Drawing.Size(173, 34);
            this.redToolStripMenuItem.Text = "Red";
            this.redToolStripMenuItem.Click += new System.EventHandler(this.redToolStripMenuItem_Click);
            // 
            // brownToolStripMenuItem
            // 
            this.brownToolStripMenuItem.BackColor = System.Drawing.Color.RosyBrown;
            this.brownToolStripMenuItem.Name = "brownToolStripMenuItem";
            this.brownToolStripMenuItem.Size = new System.Drawing.Size(173, 34);
            this.brownToolStripMenuItem.Text = "Brown";
            this.brownToolStripMenuItem.Click += new System.EventHandler(this.brownToolStripMenuItem_Click);
            // 
            // mainFormColorToolStripMenuItem
            // 
            this.mainFormColorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backGroundToolStripMenuItem1});
            this.mainFormColorToolStripMenuItem.Name = "mainFormColorToolStripMenuItem";
            this.mainFormColorToolStripMenuItem.Size = new System.Drawing.Size(279, 34);
            this.mainFormColorToolStripMenuItem.Text = "Main Form Color";
            // 
            // backGroundToolStripMenuItem1
            // 
            this.backGroundToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.greenToolStripMenuItem1,
            this.yelloToolStripMenuItem,
            this.redToolStripMenuItem1,
            this.purpleToolStripMenuItem1,
            this.blueToolStripMenuItem,
            this.whiteToolStripMenuItem});
            this.backGroundToolStripMenuItem1.Name = "backGroundToolStripMenuItem1";
            this.backGroundToolStripMenuItem1.Size = new System.Drawing.Size(232, 34);
            this.backGroundToolStripMenuItem1.Text = "BackGround";
            // 
            // greenToolStripMenuItem1
            // 
            this.greenToolStripMenuItem1.BackColor = System.Drawing.Color.Honeydew;
            this.greenToolStripMenuItem1.Name = "greenToolStripMenuItem1";
            this.greenToolStripMenuItem1.Size = new System.Drawing.Size(173, 34);
            this.greenToolStripMenuItem1.Text = "Green";
            this.greenToolStripMenuItem1.Click += new System.EventHandler(this.greenToolStripMenuItem1_Click);
            // 
            // yelloToolStripMenuItem
            // 
            this.yelloToolStripMenuItem.BackColor = System.Drawing.Color.LemonChiffon;
            this.yelloToolStripMenuItem.Name = "yelloToolStripMenuItem";
            this.yelloToolStripMenuItem.Size = new System.Drawing.Size(173, 34);
            this.yelloToolStripMenuItem.Text = "Yellow";
            this.yelloToolStripMenuItem.Click += new System.EventHandler(this.yelloToolStripMenuItem_Click);
            // 
            // redToolStripMenuItem1
            // 
            this.redToolStripMenuItem1.BackColor = System.Drawing.Color.Pink;
            this.redToolStripMenuItem1.Name = "redToolStripMenuItem1";
            this.redToolStripMenuItem1.Size = new System.Drawing.Size(173, 34);
            this.redToolStripMenuItem1.Text = "Red";
            this.redToolStripMenuItem1.Click += new System.EventHandler(this.redToolStripMenuItem1_Click);
            // 
            // purpleToolStripMenuItem1
            // 
            this.purpleToolStripMenuItem1.BackColor = System.Drawing.Color.LavenderBlush;
            this.purpleToolStripMenuItem1.Name = "purpleToolStripMenuItem1";
            this.purpleToolStripMenuItem1.Size = new System.Drawing.Size(173, 34);
            this.purpleToolStripMenuItem1.Text = "Purple";
            this.purpleToolStripMenuItem1.Click += new System.EventHandler(this.purpleToolStripMenuItem1_Click);
            // 
            // blueToolStripMenuItem
            // 
            this.blueToolStripMenuItem.BackColor = System.Drawing.Color.Azure;
            this.blueToolStripMenuItem.Name = "blueToolStripMenuItem";
            this.blueToolStripMenuItem.Size = new System.Drawing.Size(173, 34);
            this.blueToolStripMenuItem.Text = "Blue";
            this.blueToolStripMenuItem.Click += new System.EventHandler(this.blueToolStripMenuItem_Click);
            // 
            // whiteToolStripMenuItem
            // 
            this.whiteToolStripMenuItem.Name = "whiteToolStripMenuItem";
            this.whiteToolStripMenuItem.Size = new System.Drawing.Size(173, 34);
            this.whiteToolStripMenuItem.Text = "White";
            this.whiteToolStripMenuItem.Click += new System.EventHandler(this.whiteToolStripMenuItem_Click);
            // 
            // mainFormFontToolStripMenuItem
            // 
            this.mainFormFontToolStripMenuItem.Name = "mainFormFontToolStripMenuItem";
            this.mainFormFontToolStripMenuItem.Size = new System.Drawing.Size(279, 34);
            this.mainFormFontToolStripMenuItem.Text = "Main Form Font";
            this.mainFormFontToolStripMenuItem.Click += new System.EventHandler(this.mainFormFontToolStripMenuItem_Click);
            // 
            // btnPreview
            // 
            this.btnPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreview.BackColor = System.Drawing.Color.White;
            this.btnPreview.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPreview.BackgroundImage")));
            this.btnPreview.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPreview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPreview.Location = new System.Drawing.Point(901, 47);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(46, 36);
            this.btnPreview.TabIndex = 4;
            this.btnPreview.UseVisualStyleBackColor = false;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // txtTitle
            // 
            this.txtTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTitle.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtTitle.Location = new System.Drawing.Point(25, 89);
            this.txtTitle.Multiline = true;
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(887, 48);
            this.txtTitle.TabIndex = 1;
            // 
            // lbQestionnaireName
            // 
            this.lbQestionnaireName.AutoSize = true;
            this.lbQestionnaireName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbQestionnaireName.Location = new System.Drawing.Point(20, 47);
            this.lbQestionnaireName.Name = "lbQestionnaireName";
            this.lbQestionnaireName.Size = new System.Drawing.Size(241, 29);
            this.lbQestionnaireName.TabIndex = 0;
            this.lbQestionnaireName.Text = "Questionnaire Name:";
            // 
            // fileMenu
            // 
            this.fileMenu.BackColor = System.Drawing.Color.LightSkyBlue;
            this.fileMenu.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileMenu.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.fileMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.addQuestionToolStripMenuItem});
            this.fileMenu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.fileMenu.Location = new System.Drawing.Point(0, 0);
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Size = new System.Drawing.Size(950, 38);
            this.fileMenu.TabIndex = 2;
            this.fileMenu.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.closeToolStripMenuItem,
            this.previewToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(58, 34);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("saveToolStripMenuItem.Image")));
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(175, 34);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("closeToolStripMenuItem.Image")));
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(175, 34);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // previewToolStripMenuItem
            // 
            this.previewToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("previewToolStripMenuItem.Image")));
            this.previewToolStripMenuItem.Name = "previewToolStripMenuItem";
            this.previewToolStripMenuItem.Size = new System.Drawing.Size(175, 34);
            this.previewToolStripMenuItem.Text = "Preview";
            this.previewToolStripMenuItem.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // addQuestionToolStripMenuItem
            // 
            this.addQuestionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.textToolStripMenuItem,
            this.likertToolStripMenuItem,
            this.multiChoiceToolStripMenuItem,
            this.dateToolStripMenuItem,
            this.dropDownboxToolStripMenuItem,
            this.blockHeaderToolStripMenuItem,
            this.textFormQuestToolStripMenuItem});
            this.addQuestionToolStripMenuItem.Name = "addQuestionToolStripMenuItem";
            this.addQuestionToolStripMenuItem.Size = new System.Drawing.Size(158, 34);
            this.addQuestionToolStripMenuItem.Text = "Add Question";
            // 
            // textToolStripMenuItem
            // 
            this.textToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.singleTextBoxToolStripMenuItem,
            this.paragraphToolStripMenuItem});
            this.textToolStripMenuItem.Name = "textToolStripMenuItem";
            this.textToolStripMenuItem.Size = new System.Drawing.Size(246, 34);
            this.textToolStripMenuItem.Text = "Text";
            this.textToolStripMenuItem.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.textToolStripMenuItem_DropDownItemClicked);
            // 
            // singleTextBoxToolStripMenuItem
            // 
            this.singleTextBoxToolStripMenuItem.Name = "singleTextBoxToolStripMenuItem";
            this.singleTextBoxToolStripMenuItem.Size = new System.Drawing.Size(197, 34);
            this.singleTextBoxToolStripMenuItem.Text = "TextBox";
            // 
            // paragraphToolStripMenuItem
            // 
            this.paragraphToolStripMenuItem.Name = "paragraphToolStripMenuItem";
            this.paragraphToolStripMenuItem.Size = new System.Drawing.Size(197, 34);
            this.paragraphToolStripMenuItem.Text = "Paragraph";
            // 
            // likertToolStripMenuItem
            // 
            this.likertToolStripMenuItem.Name = "likertToolStripMenuItem";
            this.likertToolStripMenuItem.Size = new System.Drawing.Size(246, 34);
            this.likertToolStripMenuItem.Text = "Likert";
            this.likertToolStripMenuItem.Click += new System.EventHandler(this.likertToolStripMenuItem_Click);
            // 
            // multiChoiceToolStripMenuItem
            // 
            this.multiChoiceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.singleAnswerToolStripMenuItem,
            this.multiAnswerToolStripMenuItem});
            this.multiChoiceToolStripMenuItem.Name = "multiChoiceToolStripMenuItem";
            this.multiChoiceToolStripMenuItem.Size = new System.Drawing.Size(246, 34);
            this.multiChoiceToolStripMenuItem.Text = "Multi Options";
            this.multiChoiceToolStripMenuItem.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.multiChoiceToolStripMenuItem_DropDownItemClicked);
            // 
            // singleAnswerToolStripMenuItem
            // 
            this.singleAnswerToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("singleAnswerToolStripMenuItem.Image")));
            this.singleAnswerToolStripMenuItem.Name = "singleAnswerToolStripMenuItem";
            this.singleAnswerToolStripMenuItem.Size = new System.Drawing.Size(235, 34);
            this.singleAnswerToolStripMenuItem.Text = "Single Answer";
            // 
            // multiAnswerToolStripMenuItem
            // 
            this.multiAnswerToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("multiAnswerToolStripMenuItem.Image")));
            this.multiAnswerToolStripMenuItem.Name = "multiAnswerToolStripMenuItem";
            this.multiAnswerToolStripMenuItem.Size = new System.Drawing.Size(235, 34);
            this.multiAnswerToolStripMenuItem.Text = "Multi Answer";
            // 
            // dateToolStripMenuItem
            // 
            this.dateToolStripMenuItem.Name = "dateToolStripMenuItem";
            this.dateToolStripMenuItem.Size = new System.Drawing.Size(246, 34);
            this.dateToolStripMenuItem.Text = "Date";
            this.dateToolStripMenuItem.Click += new System.EventHandler(this.dateToolStripMenuItem_Click);
            // 
            // dropDownboxToolStripMenuItem
            // 
            this.dropDownboxToolStripMenuItem.Name = "dropDownboxToolStripMenuItem";
            this.dropDownboxToolStripMenuItem.Size = new System.Drawing.Size(246, 34);
            this.dropDownboxToolStripMenuItem.Text = "DropDownbox";
            this.dropDownboxToolStripMenuItem.Click += new System.EventHandler(this.dropDownboxToolStripMenuItem_Click);
            // 
            // blockHeaderToolStripMenuItem
            // 
            this.blockHeaderToolStripMenuItem.Name = "blockHeaderToolStripMenuItem";
            this.blockHeaderToolStripMenuItem.Size = new System.Drawing.Size(246, 34);
            this.blockHeaderToolStripMenuItem.Text = "Block Header";
            this.blockHeaderToolStripMenuItem.Click += new System.EventHandler(this.blockHeaderToolStripMenuItem_Click);
            // 
            // textFormQuestToolStripMenuItem
            // 
            this.textFormQuestToolStripMenuItem.Name = "textFormQuestToolStripMenuItem";
            this.textFormQuestToolStripMenuItem.Size = new System.Drawing.Size(246, 34);
            this.textFormQuestToolStripMenuItem.Text = "TextFormQuest";
            this.textFormQuestToolStripMenuItem.Click += new System.EventHandler(this.textFormQuestToolStripMenuItem_Click);
            // 
            // flpMainForm
            // 
            this.flpMainForm.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpMainForm.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.flpMainForm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flpMainForm.ContextMenuStrip = this.colorDialogHeader;
            this.flpMainForm.Location = new System.Drawing.Point(13, 173);
            this.flpMainForm.Name = "flpMainForm";
            this.flpMainForm.Size = new System.Drawing.Size(953, 459);
            this.flpMainForm.TabIndex = 1;
            // 
            // QuestLayout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 644);
            this.Controls.Add(this.flpMainForm);
            this.Controls.Add(this.pBanner);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.fileMenu;
            this.Name = "QuestLayout";
            this.Text = "QuestLayout";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Click += new System.EventHandler(this.QuestLayout_Click);
            this.pBanner.ResumeLayout(false);
            this.pBanner.PerformLayout();
            this.colorDialogHeader.ResumeLayout(false);
            this.fileMenu.ResumeLayout(false);
            this.fileMenu.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pBanner;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Label lbQestionnaireName;
        private System.Windows.Forms.ContextMenuStrip colorDialogHeader;
        private System.Windows.Forms.ToolStripMenuItem setColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backgroundToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mainFormColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backGroundToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mainFormFontToolStripMenuItem;
        private System.Windows.Forms.FlowLayoutPanel flpMainForm;
        private System.Windows.Forms.MenuStrip fileMenu;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem previewToolStripMenuItem;
        private System.Windows.Forms.Button btnPreview;
        private System.Windows.Forms.ToolStripMenuItem addQuestionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem textToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem multiChoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem singleAnswerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem multiAnswerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alignTitleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem centerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem singleTextBoxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paragraphToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem likertToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem greenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purpleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yellowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem brownToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem greenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem yelloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem purpleToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem blueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dropDownboxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem headerFontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem whiteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blockHeaderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem textFormQuestToolStripMenuItem;
    }
}