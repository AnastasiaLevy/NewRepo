﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using System.Windows.Forms;

namespace Questionary.Services
{
    public static class FileSaver
    {
        public static void SaveXML(CustomForm form, string fileName)
        {
            XmlSerializer ser = new XmlSerializer(typeof(CustomForm));
            XmlWriterSettings ws = new XmlWriterSettings();
            ws.NewLineHandling = NewLineHandling.Entitize;



            string fullFilePath = Application.StartupPath + "\\tests" + @"\" + fileName;
            // string fullFilePath = Application.StartupPath + "\\Templates" + @"\" + file.Text + ".xml";

            using (XmlWriter wr = XmlWriter.Create(fullFilePath, ws))
            {
                ser.Serialize(wr, form);
            }
        }
    }
}
