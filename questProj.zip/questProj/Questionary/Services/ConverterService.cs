﻿using HtmlGenerator;


namespace Questionary.Services
{
    class ConverterService
    {
        private Serializer _xmlSerializer;
        private HtmlDocument htmldoc;
        private HtmlElement head;
        private HtmlElement body;
        private HtmlDivElement wrapperDiv;
        private bool likertExist = false;
        private int likertCount = 1;
        private string _questionsId;

        public ConverterService(Serializer serializer)
        {
            _xmlSerializer = serializer;
        }

        private string getJSContent(string jsName)
        {
            string sourcePath = System.Windows.Forms.Application.StartupPath + "\\Content";
            string sourceFile = System.IO.Path.Combine(sourcePath, jsName + ".js");
            var content = System.IO.File.ReadAllText(sourceFile);
            return content;
        }

        private string getCSSContent(string cssName)
        {
            string sourcePath = System.Windows.Forms.Application.StartupPath + "\\Content";
            string sourceFile = System.IO.Path.Combine(sourcePath, cssName + ".css");
            var content = System.IO.File.ReadAllText(sourceFile);
            return content;
        }

        public string HTMLCreator(string pathToXML)
        {

            var myObject = _xmlSerializer.DeserializeFromXML(pathToXML);
            string answersFormat = myObject.Header.ExportSettings.AnswersFormat;
            _questionsId = myObject.Header.ExportSettings.QuestionsId;

            var jsContent = getJSContent("SaveAnswers")
                .Replace("{ANSWERSFORMAT}", answersFormat)
                .Replace("{SEPARATOR}", ",");
            var cssContent = getCSSContent("CommonStyles");
            
            htmldoc = new HtmlDocument();
            head = htmldoc.Head;
            body = htmldoc.Body;
            wrapperDiv = Tag.Div;
            



            foreach (var response in myObject.FormBody.Responses)
            {
                string questionTitle = (string)response.QuestionTitle.Settings.TextValue;
                if (response.Required)
                {
                    questionTitle += "(*)";                   
                }                
               
                string questionTitleAlign = "text-align:"+response.QuestionTitle.Settings.TextAlign.ToString()+";";
                wrapperDiv.AddChild(Tag.Div.WithInnerText(questionTitle)
                    .WithAttribute(Attribute.Style(questionTitleAlign)));


                switch (response.Type.ToLower())
                {
                    case "checkbox":
                    case "radio":
                        CreateCheckBoxOrRadioQuestion(response, questionTitle);
                        break;
                    case "likert":
                        CreateLikertQuestion(response, questionTitle);
                        likertExist = true;
                        break;
                    case "linecontrol":
                        //TODO
                        break;
                    case "datetime":
                        CreateDateTimeQuestion(response, questionTitle);
                        break;
                    case "textbox":
                        CreateTextBoxQuestion(response, questionTitle);
                        break;
                    case "rbx":
                        CreateRichTextBoxQuestion(response, questionTitle);
                        break;
                    case "dropdown":
                        CreateDropDownQuestion(response, questionTitle);
                        break;
                    case "blockheader":
                        CreateBlockHeader();
                        break;
                }
                wrapperDiv.AddChild(Tag.Br);
            }


            string style = getCSSContent("CommonStyles");

            if (likertExist)
            {
                var likertStyle = getCSSContent("LikertStyle").Replace("{WIDTH}",(likertCount*8).ToString());
                style += likertStyle;
            }
            string bodyStyle = string.Empty;
            bodyStyle += "background-color:" + myObject.FormBody.Settings.BackColor + ";";

            
            head.AddChild(Tag.Title.WithInnerText(myObject.Header.HeaderTextString.Settings.TextValue.ToString()));
            head.AddChild(Tag.Style.WithInnerText(style));



            string questionnaireTitleStyle = string.Empty;
            questionnaireTitleStyle += "background-color:" + myObject.Header.Settings.BackColor + ";"
                + "text-align:" + myObject.Header.HeaderTextString.Settings.TextAlign.ToString() ;

            var questionnaireTitle = Tag.Div.WithAttribute(Attribute.Style(questionnaireTitleStyle))
                .WithAttribute(Attribute.Class("questionaireTitle"))
                .WithChild(Tag.H1.WithInnerText(myObject.Header.HeaderTextString.Settings.TextValue.ToString()));

            body.AddChild(questionnaireTitle);

            wrapperDiv.AddAttribute(Attribute.Class("wrapperDiv"));
            wrapperDiv.AddAttribute(Attribute.Style(bodyStyle));

            wrapperDiv.AddChild(Tag.Input.WithAttribute(Attribute.Type("button"))
                .WithAttribute(Attribute.Id("save"))
                .WithAttribute(Attribute.Value("Finish")));

            body.AddChild(wrapperDiv);
            body.AddChild(Tag.Script.WithInnerText(jsContent));
            var result = htmldoc.Serialize();
            return result;
        }
        

        private void AddToForm(System.Collections.ObjectModel.Collection<HtmlElement> collection, CustomForm.Body.Response response)
        {
            string style = string.Empty;
            string borderStyle = string.Empty;
            switch (response.Settings.BorderStyle.ToString().ToLower())
            {
                case "fixedsingle":
                    style += "border: 1px solid;";
                    break;
                case "fixed3d":
                    style += "border: 2px inset;";
                    break;
            }

            string id = _questionsId.Equals("variable") ? response.QuestVarName : response.QuestionTitle.Settings.TextValue;

            HtmlDivElement div = Tag.Div
                .WithAttribute(Attribute.Style(style))
                .WithAttribute(Attribute.Id(id))
                .WithAttribute(Attribute.Class("answer"))
                .WithAttribute(Attribute.Type(response.Type.ToLower()));

            if(response.Required)
            {
                div.AddAttribute(Attribute.Required);
            }
            wrapperDiv.AddChild(div)
                       .WithChildren(collection);
        }


        private void CreateCheckBoxOrRadioQuestion(CustomForm.Body.Response response, string questionTitle)
        {    
            var collection = new System.Collections.ObjectModel.Collection<HtmlElement>();
            var direction = response.Settings.FlowDorection.ToString().ToLower();
            if (direction == "lefttorightn" || direction == "topdown")
            {
                for (int i = 0; i < response.Controls.Count; i++)
                {
                    var box = response.Controls[i];
                    collection.Add(Tag.Input.WithType(box.Type)
                        .WithAttribute(HtmlGenerator.Attribute.Name(questionTitle))
                        .WithAttribute(HtmlGenerator.Attribute.Value(box.Settings.TextValue)));
                    collection.Add(Tag.Label.WithInnerText(box.Settings.TextValue));
                    if (direction == "topdown")
                    {
                        collection.Add(Tag.Br);
                    }
                }
            }
            else
            {
                for (int i = response.Controls.Count - 1; i >= 0; i--)
                {
                    var box = response.Controls[i];
                    collection.Add(Tag.Input.WithType(box.Type)
                        .WithAttribute(HtmlGenerator.Attribute.Name(questionTitle))
                        .WithAttribute(HtmlGenerator.Attribute.Value(box.Settings.TextValue)));
                    collection.Add(Tag.Label.WithInnerText(box.Settings.TextValue));
                    if (direction == "bottomup")
                    {
                        collection.Add(Tag.Br);
                    }
                }
            }

            AddToForm(collection, response);
        }

        private void CreateLikertQuestion(CustomForm.Body.Response response, string questionTitle)
        {
            likertCount += response.Controls.Count;
            var liCollection = new System.Collections.ObjectModel.Collection<HtmlElement>();
            foreach (var box in response.Controls)
            {
                var liItems = new System.Collections.ObjectModel.Collection<HtmlElement>();
                liItems.Add(Tag.Input.WithType("radio")
                    .WithAttribute(HtmlGenerator.Attribute.Name(questionTitle))
                    .WithAttribute(HtmlGenerator.Attribute.Value(box.Settings.TextValue)));
                liItems.Add(Tag.Label.WithInnerText(box.Settings.TextValue.Replace("\r\n", @"<br/>")));
                var li = Tag.Li.WithChildren(liItems);
                liCollection.Add(li);
            }
            var collection= new System.Collections.ObjectModel.Collection<HtmlElement>();
            collection.Add(Tag.Ul.WithChildren(liCollection).WithAttribute(Attribute.Class("likert")));

            AddToForm(collection, response);            
        }

        private void CreateDateTimeQuestion(CustomForm.Body.Response response, string questionTitle)
        {
           
            var collection = new System.Collections.ObjectModel.Collection<HtmlElement>();
            foreach (var box in response.Controls)
            {
                collection.Add(Tag.Input.WithType("date").WithAttribute(HtmlGenerator.Attribute.Name(questionTitle)));
                collection.Add(Tag.Br);
            }
            AddToForm(collection, response);
        }

        private void CreateTextBoxQuestion(CustomForm.Body.Response response, string questionTitle)
        {
           
            var collection = new System.Collections.ObjectModel.Collection<HtmlElement>();
            foreach (var box in response.Controls)
            {
                collection.Add(Tag.Input.WithType("text").WithAttribute(HtmlGenerator.Attribute.Name(questionTitle)));
                collection.Add(Tag.Br);
            }
            AddToForm(collection, response);
        }

        private void CreateRichTextBoxQuestion(CustomForm.Body.Response response, string questionTitle)
        {
            
            var collection = new System.Collections.ObjectModel.Collection<HtmlElement>();
            foreach (var box in response.Controls)
            {
                collection.Add(Tag.TextArea.WithAttribute(HtmlGenerator.Attribute.Name(questionTitle)));
                collection.Add(Tag.Br);
            }
            AddToForm(collection, response);
        }

        private void CreateDropDownQuestion(CustomForm.Body.Response response, string questionTitle)
        {
            var collection = new System.Collections.ObjectModel.Collection<HtmlElement>();
            foreach (var box in response.Controls)
            {
                var options = new System.Collections.ObjectModel.Collection<HtmlElement>();
                foreach (string str in box.ItemList)
                {
                    options.Add(Tag.Option.WithValue(str).WithInnerText(str));
                }
                collection.Add(Tag.Select.WithChildren(options));
            }
            AddToForm(collection, response);
        }

        private void CreateBlockHeader()
        {
            wrapperDiv.AddChild(Tag.Div.WithChild(Tag.Hr).WithAttribute(Attribute.Class("answer")));
        }
    }
}
