﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Questionary
{
    public partial class LineControl : UserControl

    {
        public string Text
        {
            get
            {
                return textLine.Text;
            }
            set
            {
                textLine.Text = value;
            }
        }

        public LineControl()
        {
            InitializeComponent();
        }

        //TODO: thisn about it!
        private void textLine_TextChanged(object sender, EventArgs e)
        {
            if (textLine.TextLength == 1000)
            {
                MessageBox.Show("Max length reached");
            }
        }

        private void textLine_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Control.ModifierKeys == Keys.Enter)
            {
                
            }
        }
    }
}
