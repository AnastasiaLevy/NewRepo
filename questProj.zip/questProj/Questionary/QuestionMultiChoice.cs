﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Questionary
{
    public partial class QuestionMultiChoice : CommonCode
    {
        public int questionNumber { get; set; }
        private int _numOfResponses;
        private Control thisTxtbox;
        public QuestionMultiChoice(int number)
        {
            questionNumber = number;
            InitializeComponent();
            flpResponse.AutoScroll = true;
            thisTxtbox = txtQuestionLabel;
            thisTxtbox.Focus();
            rdbEditLabel.Checked = true;

            SetTransparent(rdbEditLabel);
            SetTransparent(lblResponseType);
            SetTransparent(lblQuestionNum);
            SetTransparent(rdbEditText);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _numOfResponses--;
            RadioButton rbtn =  this.Controls.Find("rbtn" + (_numOfResponses), true).FirstOrDefault() as RadioButton;
            flpResponse.Controls.Remove(rbtn);

            
        }

        private void btnAddResp_Click(object sender, EventArgs e)
        {
            
            RadioButton rbtn = new RadioButton();
            rbtn.Name = "rbtn" + _numOfResponses;
            rbtn.Text = txtOptiontxt.Text;
            rbtn.AutoSize = true;
            flpResponse.Controls.Add(rbtn);
          
            _numOfResponses++;
        }

        private void cbFlowDirection_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbFlowDirection.Text)
            {
                case "Bottom Up":
                    flpResponse.FlowDirection = FlowDirection.BottomUp;
                    break;
                case "Right To Left":
                    flpResponse.FlowDirection = FlowDirection.RightToLeft;
                    break;
                case "Left To Right":
                    flpResponse.FlowDirection = FlowDirection.LeftToRight;
                    break;
                case "Top Down":
                    flpResponse.FlowDirection = FlowDirection.TopDown;
                    break;
            }
        }

        private void chbxWrap_Click(object sender, EventArgs e)
        {
            if (chbxWrap.Checked)
            {
                flpResponse.WrapContents = true;
                flpResponse.AutoSize = true;
            }
                
            else
                flpResponse.WrapContents = false;
        }
   
        private void rdbEditLabel_CheckedChanged(object sender, EventArgs e)
        {
            thisTxtbox = txtQuestionLabel;
            borderToolStripMenuItem.Enabled = true;
            textalignToolStripMenuItem.Enabled = true;

        }

        private void rdbEditText_CheckedChanged(object sender, EventArgs e)
        {
            thisTxtbox = flpResponse;
            borderToolStripMenuItem.Enabled = false;
            textalignToolStripMenuItem.Enabled = false;


        }

        private void borderToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            string txt = e.ClickedItem.Text;
            
            if (rdbEditLabel.Checked)
            {
                TextBox text = (TextBox)thisTxtbox;
                text.BorderStyle = Util.MapBorderStyle(txt);
            }
          
        }

        private void textalignToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (rdbEditLabel.Checked)
            {
                TextBox text = (TextBox)thisTxtbox;
                string txt = e.ClickedItem.Text;
            
            }
        }

        private void fontstyleToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            string txt = e.ClickedItem.Text;

            switch (txt)
            {
                case "bold":
                    thisTxtbox.Font = new Font(thisTxtbox.Font.FontFamily, thisTxtbox.Font.Size, FontStyle.Bold);
                    break;
                case "italic":
                    thisTxtbox.Font = new Font(thisTxtbox.Font.FontFamily, thisTxtbox.Font.Size, FontStyle.Italic);
                    break;
                case "bold italic":
                    thisTxtbox.Font = new Font(thisTxtbox.Font.FontFamily, thisTxtbox.Font.Size, FontStyle.Italic | FontStyle.Bold);
                    break;
                default:
                    thisTxtbox.Font = new Font(thisTxtbox.Font.FontFamily, thisTxtbox.Font.Size, FontStyle.Regular);
                    break;
            }
        }

        private void fontToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            string txt = e.ClickedItem.Text;
            thisTxtbox.Font = new Font(txt, thisTxtbox.Font.Size);
        }
        private void fontsizeToolStripMenuItem_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            int size = Convert.ToInt16(e.ClickedItem.Text);

            thisTxtbox.Font = new Font(thisTxtbox.Font.FontFamily, size);

        }

        private void previewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FlowLayoutPanel flp = new FlowLayoutPanel();
            Label lbl = new Label();
            lbl.Text = txtQuestionLabel.Text;
            lbl.Font = txtQuestionLabel.Font;
            lbl.AutoSize = true;
            lbl.Width = txtQuestionLabel.Width;
            //lbl.TextAlign = txtQuestionLabel.TextAlign;
            flp.Controls.Add(lbl);
            
            var frm = Application.OpenForms.Cast<QuestLayout>().Where(x => x.Name == "QuestLayout").FirstOrDefault();
            ViewForm vf = new ViewForm();
            vf.Size = this.Size;

            Panel setUp = frm.Controls.Find("pBanner", true).FirstOrDefault() as Panel;
            //Panel setUp = pBanner;
            Panel header = new Panel();
            header.BackColor = setUp.BackColor;
            header.ForeColor = setUp.ForeColor;
            header.Anchor = setUp.Anchor;
            header.Size = setUp.Size;
            header.Location = setUp.Location;

            //=======================
            TextBox txtTitle = frm.Controls.Find("txtTitle", true).FirstOrDefault() as TextBox;
            TextBox questTitle = new TextBox();
            questTitle.Text = txtTitle.Text;
            questTitle.Font = txtTitle.Font;
            questTitle.Location = txtTitle.Location;
            questTitle.Anchor = txtTitle.Anchor;
            questTitle.AutoSize = true;
            questTitle.Enabled = false;
            questTitle.BorderStyle = BorderStyle.None;
            questTitle.BackColor = setUp.BackColor;
            questTitle.Location = txtTitle.Location;
            questTitle.Size = txtTitle.Size;
            questTitle.Multiline = true;
            questTitle.WordWrap = true;
            //=========================

           


            setUp = frm.Controls.Find("flpMainForm", true).FirstOrDefault() as Panel;
            Panel body = new Panel();

            body.BackColor = setUp.BackColor;
            body.ForeColor = setUp.ForeColor;
            body.Location = setUp.Location;
            body.Margin = setUp.Margin;
            body.Anchor = setUp.Anchor;
            body.AutoSize = true;
            body.Size = setUp.Size;
            body.Controls.Add(flp);

            header.Controls.Add(questTitle);
            vf.Controls.Add(body);
            vf.Controls.Add(header);
         
            vf.Show();
        }

        private void addQuestionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frm = Application.OpenForms.Cast<QuestLayout>().Where(x => x.Name == "QuestLayout").FirstOrDefault();
            Panel p = frm.Controls.Find("p" + questionNumber, true).FirstOrDefault() as Panel;
            //Panel p = frm.Controls.OfType<Panel>().Where(x=> x.Name.StartsWith("drop")) as Panel;
            Panel flp = new Panel();

          
            Label lbl = new Label();
            lbl.Text = txtQuestionLabel.Text;
            lbl.Font = txtQuestionLabel.Font;
            lbl.AutoSize = true;
            lbl.Width = txtQuestionLabel.Width;
            flp.Size = new Size(1000, 100);
            flp.BackColor = Color.AliceBlue;
            foreach(Control c in flpResponse.Controls)
            {
                flp.Controls.Add(c);
            }
 
            p.BringToFront();
            p.Controls.Add(lbl);
            p.Controls.Add(flp);
            
          
        }
    }
}
