﻿using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Serialization;
using static Questionary.CustomForm.Body.Response;

namespace Questionary
{
    public static class LoadFromXML
    {

        public static void ReadProps(string fileName)
        {
            CustomForm myObject = ReadXml(fileName);

            ViewForm vf = new ViewForm();
            //vf.Size = new Size(100, 100);
            //vf.AutoScaleMode = AutoScaleMode.Font;
            vf.AutoSize = true;
            TextBox questTitle = new TextBox();
            FlowLayoutPanel header = new FlowLayoutPanel();
            //Color test = Color.FromArgb(myObject.Header.Settings.Test);
            header.BackColor = Color.FromName(myObject.Header.Settings.BackColor);
            header.ForeColor = Color.FromName(myObject.Header.Settings.ForeColor);
            header.Anchor = myObject.Header.Settings.Anchor;
            header.Location = myObject.Header.Settings.Location;
            header.Size = myObject.Header.Settings.Size;//new Size(2000, 400);
            header.BorderStyle = BorderStyle.Fixed3D;
            header.Dock = DockStyle.Top;

            questTitle.Text = myObject.Header.HeaderTextString.Settings.TextValue;
            questTitle.Font = new Font(myObject.Header.HeaderTextString.Settings.font.FontFamily,
                                       myObject.Header.HeaderTextString.Settings.font.Size,
                                       myObject.Header.HeaderTextString.Settings.font.Style);
            //questTitle.Location = myObject.Header.HeaderTextString.Settings.Location;
            questTitle.Top = (header.Height - questTitle.Height) / 2;
            questTitle.Anchor = myObject.Header.HeaderTextString.Settings.Anchor;
            questTitle.BorderStyle = myObject.Header.HeaderTextString.Settings.BorderStyle;
            questTitle.BackColor = header.BackColor;//Color.FromName(myObject.Header.HeaderTextString.Settings.BackColor);
            questTitle.ForeColor = Color.FromName(myObject.Header.HeaderTextString.Settings.ForeColor);
            questTitle.Size = new Size(header.Width - 10, Convert.ToInt32(questTitle.Font.GetHeight()));//myObject.Header.HeaderTextString.Settings.Size;
            questTitle.AutoSize = true;
            questTitle.Multiline = true;
            questTitle.MinimumSize = new Size(0, 50);
            questTitle.TextAlign = myObject.Header.HeaderTextString.Settings.TextAlign;

            header.Controls.Add(questTitle);
            FlowLayoutPanel body = new FlowLayoutPanel();
            body.FlowDirection = FlowDirection.TopDown;
            body.WrapContents = true;
            body.Name = "body";
            body.WrapContents = false;
            body.BackColor = Color.FromName(myObject.FormBody.Settings.BackColor);
            body.ForeColor = Color.FromName(myObject.FormBody.Settings.ForeColor);
            body.Location = new Point(0, header.Height);//myObject.FormBody.Settings.Location;
            //body.Size = new Size(header.Size.Width, 1800); //myObject.FormBody.Settings.Size;
            body.AutoScroll = true;
            body.AutoSize = true;
            body.BorderStyle = myObject.FormBody.Settings.BorderStyle;
            body.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;
            body.Dock = DockStyle.Fill;
            int i = 0;
            foreach (var c in myObject.FormBody.Responses)
            {
                FlowLayoutPanel flp = new FlowLayoutPanel();
                flp.AutoSizeMode = AutoSizeMode.GrowAndShrink;
                flp.FlowDirection = c.Settings.FlowDorection;
                flp.WrapContents = c.Settings.WrapContent;
                flp.Font = new Font(c.Settings.font.FontFamily,
                                    c.Settings.font.Size,
                                    c.Settings.font.Style);
                flp.BorderStyle = c.Settings.BorderStyle;
                flp.Anchor = c.Settings.Anchor;
                flp.Size = c.Settings.Size;
                flp.AutoSize = true;
                flp.Name = c.Type;
                flp.MinimumSize = new Size(header.Size.Width, 0);

                TextBox qlbl = new TextBox();
                qlbl.Text = c.QuestionTitle.Settings.TextValue;
                TextBox txtVar = new TextBox();
                txtVar.Visible = false;
                txtVar.Text = c.QuestVarName;
                body.Controls.Add(txtVar);
                if (c.Required == true)
                {
                    qlbl.Name = "Required";
                    qlbl.Text += "(*)";
                }

                //qlbl.Name = i.ToString();

                qlbl.Font = new Font(c.QuestionTitle.Settings.font.FontFamily,
                                     c.QuestionTitle.Settings.font.Size,
                                     c.QuestionTitle.Settings.font.Style);
                qlbl.ReadOnly = true;
                qlbl.SelectionLength = 0;
                qlbl.TextAlign = c.QuestionTitle.Settings.TextAlign;
                qlbl.Anchor = c.QuestionTitle.Settings.Anchor;
                qlbl.AutoSize = true;
                qlbl.BorderStyle = c.QuestionTitle.Settings.BorderStyle;
                qlbl.BackColor = body.BackColor;
                qlbl.BorderStyle = BorderStyle.None;
                qlbl.Size = c.QuestionTitle.Settings.Size;
                qlbl.Multiline = true;
                qlbl.WordWrap = true;
                qlbl.Dock = DockStyle.Top;
                qlbl.Name = c.Type;
                body.Controls.Add(qlbl);
                Control copyTo = new Control();
                foreach (var box in c.Controls)
                {
                    if (box.Type == "checkbox")
                    {

                        copyTo = new CheckBox();
                        copyTo.Name = "checkbox";
                        //copyTo.Dock = DockStyle.Fill;
                        ((CheckBox)copyTo).Checked = box.isChecked;
                        ((CheckBox)copyTo).CheckAlign = box.CheckAlign;
                        CommonSettings(myObject, copyTo, box);

                    }
                    else if (box.Type == "radio")
                    {

                        copyTo = new RadioButton();
                        copyTo.Name = "radio";
                        ((RadioButton)copyTo).Checked = box.isChecked;
                        ((RadioButton)copyTo).CheckAlign = box.CheckAlign;
                        CommonSettings(myObject, copyTo, box);

                    }
                    else if (box.Type == "Likert")
                    {

                        copyTo = new LikertUnit();
                        copyTo.Name = "Likert";
                        ((LikertUnit)copyTo).boxText = box.Settings.TextValue;
                        ((LikertUnit)copyTo).BorderStyle = BorderStyle.None;//box.Settings.BorderStyle;
                        ((LikertUnit)copyTo).AutoSize = true;
                        ((LikertUnit)copyTo).boxEdit = false;
                        CommonSettings(myObject, copyTo, box);


                    }
                    else if (box.Type == "LineControl")
                    {

                        copyTo = new LineControl();
                        copyTo.Name = "LineControl";
                        ((LineControl)copyTo).AutoSize = true;
                        CommonSettings(myObject, copyTo, box);

                    }
                    else if (box.Type == "DateTime")
                    {
                        copyTo = new DateTimePicker();
                        copyTo.Name = "DateTime";
                    }
                    else if (box.Type == "TextBox")
                    {

                        copyTo = new TextBox();
                        copyTo.Name = "TextBox";
                        CommonSettings(myObject, copyTo, box);

                    }
                    else if (box.Type == "RichTextBox")
                    {

                        copyTo = new RichTextBox();
                        copyTo.Name = "RichTextBox";
                        CommonSettings(myObject, copyTo, box);
                    }
                    else if (box.Type == "DropDown")
                    {
                        copyTo = new ComboBox();
                        copyTo.Name = "DropDown";
                        int newWidth = 0;
                        int width = ((ComboBox)copyTo).DropDownWidth;
                        foreach (string item in box.ItemList)
                        {
                            ((ComboBox)copyTo).Items.Add(item);
                            newWidth = TextRenderer.MeasureText(item.ToString(), copyTo.Font).Width + SystemInformation.VerticalScrollBarWidth;
                            if (width < newWidth)
                            {
                                width = newWidth;
                            }
                        }
                        ((ComboBox)copyTo).Width = width;
                    }

                

                    // buttonsPanel.Controls.Add(copyTo);
                    flp.Controls.Add(copyTo);
                    flp.Name = copyTo.Name;
                }

                body.Controls.Add(flp);
            }

            //  header.Controls.Add(questTitle);

            vf.Controls.Add(header);
            Panel center = vf.Controls.Find("center", true).FirstOrDefault() as Panel;
            center.Controls.Add(body);
            vf.Padding = new Padding(10);
            vf.Show();
        }

        private static CustomForm ReadXml(string fileName)
        {
            CustomForm myObject;
            XmlSerializer mySerializer =
            new XmlSerializer(typeof(CustomForm));
            string filePath = Application.StartupPath + "\\tests" + @"\" + fileName;
            FileStream myFileStream =
            new FileStream(filePath, FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);
            myObject = (CustomForm)
            mySerializer.Deserialize(myFileStream);
            myFileStream.Dispose();
            return myObject;
        }

        private static void CommonSettings(CustomForm myObject, Control copyTo, CustomForm.Body.Response.MyControl box)
        {
            copyTo.Anchor = box.Settings.Anchor;
            copyTo.AutoSize = box.Settings.AutoSize;
            copyTo.Location = box.Settings.Location;
            copyTo.Text = box.Settings.TextValue;
            copyTo.Font = new Font(box.Settings.font.FontFamily,
                                    box.Settings.font.Size,
                                    box.Settings.font.Style);
            copyTo.Size = box.Settings.Size;
            copyTo.BackColor = Color.FromName(box.Settings.BackColor == null ? myObject.FormBody.Settings.BackColor : box.Settings.BackColor);
            copyTo.ForeColor = Color.FromName(box.Settings.BackColor == null ? myObject.FormBody.Settings.ForeColor : box.Settings.ForeColor);
        }

        public static void LoadForEdit(string fileName)
        {
            CustomForm myObject = ReadXml(fileName);

            int i = 0;

            QuestLayout ql = new QuestLayout(myObject.Header.ExportSettings.AnswersFormat, myObject.Header.ExportSettings.QuestionsId);
            ql.FileName = fileName;
            TextBox txb = ql.Controls.Find("txtTitle", true).FirstOrDefault() as TextBox;
            Panel banner = ql.Controls.Find("pBanner", true).FirstOrDefault() as Panel;
            FlowLayoutPanel flp = ql.Controls.Find("flpMainForm", true).FirstOrDefault() as FlowLayoutPanel;
            flp.BackColor = Color.FromName(myObject.FormBody.Settings.BackColor);
            flp.Font = new Font(myObject.FormBody.Settings.font.FontFamily,
                                       myObject.FormBody.Settings.font.Size,
                                       myObject.FormBody.Settings.font.Style);
            banner.BackColor = Color.FromName(myObject.Header.Settings.BackColor);
            banner.ForeColor = Color.FromName(myObject.Header.Settings.ForeColor);
            txb.Text = myObject.Header.HeaderTextString.Settings.TextValue;

            txb.Font = new Font(myObject.Header.HeaderTextString.Settings.font.FontFamily,
                                       myObject.Header.HeaderTextString.Settings.font.Size,
                                       myObject.Header.HeaderTextString.Settings.font.Style);
            txb.TextAlign = myObject.Header.HeaderTextString.Settings.TextAlign;
            //TextBox txbVar = ql.Controls.Find("txtTitle", true).FirstOrDefault() as TextBox;
            foreach (var c in myObject.FormBody.Responses)
            {
                if (c.Type == "DateTime")
                {
                    Panel1 p1 = new Panel1(i, "DateTime");

                    FlowLayoutPanel flpResponse = CreatePanelControls(ql, c, p1);
                    flpResponse.Font = new Font(c.Settings.font.FontFamily,
                                                     c.Settings.font.Size,
                                                     c.Settings.font.Style);
                    DateTimePicker dp = new DateTimePicker();
                    dp.Name = "dp" + c.QuestionNumber;
                    
                    flpResponse.Controls.Add(dp);
                }
                else if (c.Type == "TextBox")
                {
                    Panel1 p1 = new Panel1(i, "TextBox");

                    FlowLayoutPanel flpResponse = CreatePanelControls(ql, c, p1);
                    flpResponse.Font = new Font(c.Settings.font.FontFamily,
                                                     c.Settings.font.Size,
                                                     c.Settings.font.Style);
                    int num = 0;
                    foreach (MyControl control in c.Controls)
                    {
                        TextBox tb = new TextBox();
                        tb.Name = "tb" + num;
                        tb.Anchor = AnchorStyles.Left | AnchorStyles.Right;
                        tb.Width = flpResponse.Width - 100;
                      
                        flpResponse.Controls.Add(tb);
                        flpResponse.AutoScroll = true;
                        i++;
                    }

                }
                else if (c.Type == "RBX")
                {
                    Panel1 p1 = new Panel1(i, "Paragraph");

                    FlowLayoutPanel flpResponse = CreatePanelControls(ql, c, p1);
                    flpResponse.Font = new Font(c.Settings.font.FontFamily,
                                                     c.Settings.font.Size,
                                                     c.Settings.font.Style);
                    RichTextBox rb = new RichTextBox();
                    int num = 0;
                    foreach (MyControl control in c.Controls)
                    {
                        rb.Name = "rb";
                        rb.Height = flpResponse.Height - 20;
                        rb.Width = flpResponse.Width - 20;
                        flpResponse.Controls.Add(rb);
                        num++;
                    }

                }
                else if (c.Type == "Likert")
                {
                    Panel1 p1 = new Panel1(i, "Likert");

                    FlowLayoutPanel flpResponse = CreatePanelControls(ql, c, p1);
                    flpResponse.Font = new Font(c.Settings.font.FontFamily,
                                                     c.Settings.font.Size,
                                                     c.Settings.font.Style);
                    //flpResponse.Width = ClientSize.Width;
                    int likertSize = c.Controls.Count;
                    int luWidth = flpResponse.Width / (likertSize + 5);//1250 
                    int num = 0;
                    foreach (MyControl control in c.Controls)
                    {
                        LikertUnit lu = new LikertUnit();
                        lu.Name = "lu" + num;
                        lu.boxText = control.Settings.TextValue;
                        lu.Width = luWidth;
                        lu.Font = new Font(control.Settings.font.FontFamily,
                                    control.Settings.font.Size,
                                   control.Settings.font.Style);
                        
                        flpResponse.Controls.Add(lu);
                        num++;
                    }


                }
                else if (c.Type == "checkbox")
                {
                    Panel1 p1 = new Panel1(i, "Multi Answer");
                    FlowLayoutPanel flpResponse = CreatePanelControls(ql, c, p1);
                    flpResponse.Font = new Font(c.Settings.font.FontFamily,
                                                     c.Settings.font.Size,
                                                     c.Settings.font.Style);
                    int num = 0;
                    foreach (MyControl control in c.Controls)
                    {
                        CheckBox cb = new CheckBox();
                        cb.Name = "cb" + num;
                        cb.Text = control.Settings.TextValue;
                        cb.AutoSize = true;
                       
                        // menuStripEdit.Items.Remove(toolStripTextAmoun);
                        flpResponse.Controls.Add(cb);
                        flpResponse.FlowDirection = c.Settings.FlowDorection;
                        num++;
                    }
                }
                else if (c.Type == "Radio")
                {
                    Panel1 p1 = new Panel1(i, "Single Answer");
                    FlowLayoutPanel flpResponse = CreatePanelControls(ql, c, p1);
                    flpResponse.Font = new Font(c.Settings.font.FontFamily,
                                                     c.Settings.font.Size,
                                                     c.Settings.font.Style);
                    flpResponse.FlowDirection = c.Settings.FlowDorection;
                    int num = 0;
                    foreach (MyControl control in c.Controls)
                    {
                        RadioButton rbtn = new RadioButton();
                        rbtn.Name = "rbtn" + num;
                        rbtn.Text = control.Settings.TextValue;
                        rbtn.AutoSize = true;
                        flpResponse.Controls.Add(rbtn);
                        num++;
                    }

                }
                else if (c.Type == "DropDown")
                {
                    Panel1 p1 = new Panel1(i, "DropDown");
                    FlowLayoutPanel flpResponse = CreatePanelControls(ql, c, p1);
                    flpResponse.Font = new Font(c.Settings.font.FontFamily,
                                                     c.Settings.font.Size,
                                                     c.Settings.font.Style);
                    ComboBox cb = p1.Controls.Find("cb0", true).FirstOrDefault() as ComboBox;
                    int newWidth = 0;
                    int width = (cb).DropDownWidth;
                    RichTextBox rbx = p1.Controls.Find("rbx0", true).FirstOrDefault() as RichTextBox;
                    foreach (string item in c.Controls[0].ItemList)
                    {
                        cb.Items.Add(item);
                        rbx.Text += item + ",";
                        newWidth = TextRenderer.MeasureText(item.ToString(), cb.Font).Width + SystemInformation.VerticalScrollBarWidth;
                        if (width < newWidth)
                        {
                            width = newWidth;
                        }
                    }
                    rbx.Text.TrimEnd(',');
                    cb.Width = width;
                }
                else if (c.Type == "BlockHeader")
                {
                    Panel1 p1 = new Panel1(i, "header");
                    FlowLayoutPanel flpResponse = CreatePanelControls(ql, c, p1);


                }
                else if (c.Type == "TextFormatQuest")
                {
                    TextFormatQuest tfq = new TextFormatQuest();

                    //tfq.Width = flpResponse.Width;
                    //flpResponse.Controls.Add(tfq);
                }
                
            }

            ql.Show();
        }

        private static FlowLayoutPanel CreatePanelControls(QuestLayout ql, CustomForm.Body.Response c, Panel1 p1)
        {
            ql.CreatePanel(p1);


            TextBox txtBox = p1.Controls.Find("txtQuestionText", true).FirstOrDefault() as TextBox;

            if (txtBox == null)
            {
                txtBox = p1.Controls.Find("BlockHeader", true).FirstOrDefault() as TextBox;
            }

            FlowLayoutPanel flpResponse = p1.Controls.Find("flpResponse", true).FirstOrDefault() as FlowLayoutPanel;



            txtBox.Text = c.QuestionTitle.Settings.TextValue;
            txtBox.TextAlign = c.QuestionTitle.Settings.TextAlign;
            txtBox.Font = new Font(c.QuestionTitle.Settings.font.FontFamily,
                             c.QuestionTitle.Settings.font.Size,
                             c.QuestionTitle.Settings.font.Style);
            CheckBox cb = p1.Controls.Find("cbRequired", true).FirstOrDefault() as CheckBox;
            cb.Checked = c.Required;
            TextBox txtVar = p1.Controls.Find("txtVarName", true).FirstOrDefault() as TextBox;
            txtVar.Text = c.QuestVarName;
            flpResponse.BorderStyle = c.Settings.BorderStyle;
            return flpResponse;
        }

        private static void CreateControls(QuestLayout ql, CustomForm.Body.Response c, Panel1 p1)
        {
            ql.CreatePanel(p1);

            TextBox txtBox = p1.Controls.Find("txtQuestionText", true).FirstOrDefault() as TextBox;
            FlowLayoutPanel flpResponse = p1.Controls.Find("flpResponse", true).FirstOrDefault() as FlowLayoutPanel;
            txtBox.TextAlign = c.QuestionTitle.Settings.TextAlign;
            txtBox.Font = new Font(c.QuestionTitle.Settings.font.FontFamily,
                             c.QuestionTitle.Settings.font.Size,
                             c.QuestionTitle.Settings.font.Style);
            CheckBox cb = p1.Controls.Find("cbRequired", true).FirstOrDefault() as CheckBox;
            cb.Checked = c.Required;
        }
    }

}
