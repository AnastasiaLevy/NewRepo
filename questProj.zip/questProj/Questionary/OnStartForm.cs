﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using static Questionary.CustomForm.Body.Response;

namespace Questionary
{
    public partial class OnStartForm : Form
    {
        public OnStartForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ExportToHTMLOptions exportOptions = new ExportToHTMLOptions();
            exportOptions.Show();
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void startTest_Click(object sender, EventArgs e)
        {
            SelectFile sf = new SelectFile("start");
            sf.ShowDialog();
            this.WindowState = FormWindowState.Minimized;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.cogquiz.com");
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/CogQuiz-1644904339158958/");
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://twitter.com/cogquizcom");
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.linkedin.com/in/hasker-davis-8849a914");
        }

        private void startTest_MouseHover(object sender, EventArgs e)
        {
            startTest.ForeColor = Color.White;
        }

        private void startTest_MouseLeave(object sender, EventArgs e)
        {
            startTest.ForeColor = Color.Black;
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void Update_Click(object sender, EventArgs e)
        {
            SelectFile sf = new SelectFile("edit");
            sf.ShowDialog();
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnShare_Click_1(object sender, EventArgs e)
        {

        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            FileDialog save = new OpenFileDialog();
            save.Filter = "XML Files (*.xml)|*.xml";
            save.FilterIndex = 0;
            save.DefaultExt = "xml";

            if (save.ShowDialog() == DialogResult.OK)
            {
                string sourcePath = Path.GetFullPath(save.FileName);
                string sourceFile = System.IO.Path.Combine(sourcePath, save.FileName);
              

                if (!String.Equals(Path.GetExtension(save.FileName),
                       ".xml",
                       StringComparison.OrdinalIgnoreCase))
                {
                    // Invalid file type selected; display an error.
                    MessageBox.Show("The type of the selected file is not supported by this application. You must select an XML file.",
                                    "Invalid File Type",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);

                    // Optionally, force the user to select another file.
                    // ...
                }
                string destFile = System.IO.Path.Combine(Application.StartupPath + "\\tests", Path.GetFileNameWithoutExtension(save.FileName));

                System.IO.File.Copy(sourceFile, destFile+".xml", true);
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            SelectFile sf = new SelectFile("export");
            sf.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SelectFile sf = new SelectFile("delete");
            sf.Show();

        }

        private void OnStartForm_Load(object sender, EventArgs e)
        {

        }

        private void btnExportToHTML_Click(object sender, EventArgs e)
        {
            SelectFile sf = new SelectFile("exportToHTML");
            sf.Show();
        }

        //private static void CreateControls(QuestLayout ql, CustomForm.Body.Response c, Panel1 p1)
        //{
        //    ql.CreatePanel(p1);

        //    TextBox txtBox = p1.Controls.Find("txtQuestionText", true).FirstOrDefault() as TextBox;
        //    FlowLayoutPanel flpResponse = p1.Controls.Find("flpResponse", true).FirstOrDefault() as FlowLayoutPanel;
        //    txtBox.TextAlign = c.QuestionTitle.Settings.TextAlign;
        //    txtBox.Font = new Font(c.QuestionTitle.Settings.font.FontFamily,
        //                     c.QuestionTitle.Settings.font.Size,
        //                     c.QuestionTitle.Settings.font.Style);
        //    CheckBox cb = p1.Controls.Find("cbRequired", true).FirstOrDefault() as CheckBox;
        //    cb.Checked = c.Required;
        //}
    }
}
