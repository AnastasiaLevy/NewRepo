﻿using System;
using System.Linq;
using System.Windows.Forms;
using Questionary.Services;
using System.IO;


namespace Questionary
{
    public partial class ExportToHTMLOptions : Form
    {
        private string _questName;
        public ExportToHTMLOptions()
        {
            InitializeComponent();
        }

        public ExportToHTMLOptions(string questName)
        {
            InitializeComponent();
            _questName = questName;
        }

        private void Ok_Click(object sender, EventArgs e)
        {            
            var answersFormat = AnswersFormatBox.Controls.OfType<RadioButton>()
                                      .FirstOrDefault(r => r.Checked).Name.ToLower();
            var questionsId = QuestionsIdBox.Controls.OfType<RadioButton>()
                                     .FirstOrDefault(r => r.Checked).Name.ToLower();
            this.Close();

            QuestLayout ql = new QuestLayout(answersFormat, questionsId);
            ql.Show();
        }

        private void AswersFormatBox_Enter(object sender, EventArgs e)
        {

        }

       
    }
}
