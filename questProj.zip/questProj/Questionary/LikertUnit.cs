﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Questionary
{
    public partial class LikertUnit :UserControl
    {
        public bool boxEdit
        {
            get
            {
                return luText.ReadOnly;
            }
            set
            {
                luText.ReadOnly = value;
            }
        }
        public string boxText
        {
            get
            {
                return luText.Text;
            }
            set
            {
                luText.Text = value;
            }
        }
         public bool boxChecked
        {
            get
            {
                return checkButton.Checked;
            }
            set
            {
                checkButton.Checked = value;
            }
        }


        public BorderStyle boxBorder
        {
            get
            {
                return luText.BorderStyle;
            }
            set
            {
                luText.BorderStyle = value;
            }
        }
        public LikertUnit()
        {
            InitializeComponent();
         
            luText.Multiline = true;
            luText.TextAlign = HorizontalAlignment.Center;
            luText.WordWrap = true; 
            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkButton.Checked)
                checkButton.ImageIndex = 0;
            else
                checkButton.ImageIndex = 1;
        }
    }
}
