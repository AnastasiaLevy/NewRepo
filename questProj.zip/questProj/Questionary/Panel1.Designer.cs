﻿namespace Questionary
{
    partial class Panel1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Panel1));
            this.chbxWrap = new System.Windows.Forms.CheckBox();
            this.txtQuestionText = new System.Windows.Forms.TextBox();
            this.flpResponse = new System.Windows.Forms.FlowLayoutPanel();
            this.menuStripEdit = new System.Windows.Forms.MenuStrip();
            this.fontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.moFontLabel = new System.Windows.Forms.ToolStripMenuItem();
            this.moFontResponse = new System.Windows.Forms.ToolStripMenuItem();
            this.moTextAlign = new System.Windows.Forms.ToolStripMenuItem();
            this.leftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.centerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cbFlowDirection = new System.Windows.Forms.ToolStripMenuItem();
            this.topToBottomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leftToRightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rightToLeftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomUpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.singleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.singleDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alignToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomCenterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomLeftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomRightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.middleCenterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.middleLeftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.middleRightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.topCenterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.topLeftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.topRightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextAmoun = new System.Windows.Forms.ToolStripTextBox();
            this.txtOptiontxt = new System.Windows.Forms.ToolStripTextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.cbRequired = new System.Windows.Forms.CheckBox();
            this.txtVarName = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuStripEdit.SuspendLayout();
            this.SuspendLayout();
            // 
            // chbxWrap
            // 
            this.chbxWrap.AutoSize = true;
            this.chbxWrap.Location = new System.Drawing.Point(966, 16);
            this.chbxWrap.Name = "chbxWrap";
            this.chbxWrap.Size = new System.Drawing.Size(134, 24);
            this.chbxWrap.TabIndex = 2;
            this.chbxWrap.Text = "Wrap Content";
            this.chbxWrap.UseVisualStyleBackColor = true;
            this.chbxWrap.CheckedChanged += new System.EventHandler(this.chbxWrap_Click);
            // 
            // txtQuestionText
            // 
            this.txtQuestionText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtQuestionText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuestionText.Location = new System.Drawing.Point(146, 55);
            this.txtQuestionText.Multiline = true;
            this.txtQuestionText.Name = "txtQuestionText";
            this.txtQuestionText.Size = new System.Drawing.Size(817, 34);
            this.txtQuestionText.TabIndex = 3;
            this.txtQuestionText.Text = "Enter Question Text";
            this.txtQuestionText.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtQuestionText_MouseClick);
            this.txtQuestionText.MouseLeave += new System.EventHandler(this.txtQuestionText_MouseLeave);
            // 
            // flpResponse
            // 
            this.flpResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.flpResponse.AutoScroll = true;
            this.flpResponse.AutoSize = true;
            this.flpResponse.BackColor = System.Drawing.Color.White;
            this.flpResponse.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flpResponse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flpResponse.Location = new System.Drawing.Point(17, 95);
            this.flpResponse.Name = "flpResponse";
            this.flpResponse.Size = new System.Drawing.Size(1300, 145);
            this.flpResponse.TabIndex = 5;
            // 
            // menuStripEdit
            // 
            this.menuStripEdit.BackColor = System.Drawing.Color.LightSkyBlue;
            this.menuStripEdit.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStripEdit.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStripEdit.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStripEdit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fontToolStripMenuItem,
            this.moTextAlign,
            this.cbFlowDirection,
            this.borderToolStripMenuItem,
            this.alignToolStripMenuItem,
            this.toolStripTextAmoun,
            this.txtOptiontxt});
            this.menuStripEdit.Location = new System.Drawing.Point(0, 0);
            this.menuStripEdit.Name = "menuStripEdit";
            this.menuStripEdit.Size = new System.Drawing.Size(1045, 41);
            this.menuStripEdit.TabIndex = 6;
            this.menuStripEdit.Text = "menuStrip1";
            // 
            // fontToolStripMenuItem
            // 
            this.fontToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.moFontLabel,
            this.moFontResponse});
            this.fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            this.fontToolStripMenuItem.Size = new System.Drawing.Size(68, 37);
            this.fontToolStripMenuItem.Text = "Font";
            this.fontToolStripMenuItem.ToolTipText = "Set font for Question Title and Response buttons";
            // 
            // moFontLabel
            // 
            this.moFontLabel.Name = "moFontLabel";
            this.moFontLabel.Size = new System.Drawing.Size(191, 34);
            this.moFontLabel.Text = "Label";
            this.moFontLabel.Click += new System.EventHandler(this.moFontLabel_Click);
            // 
            // moFontResponse
            // 
            this.moFontResponse.Name = "moFontResponse";
            this.moFontResponse.Size = new System.Drawing.Size(191, 34);
            this.moFontResponse.Text = "Response";
            this.moFontResponse.Click += new System.EventHandler(this.moFontResponse_Click);
            // 
            // moTextAlign
            // 
            this.moTextAlign.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.leftToolStripMenuItem,
            this.rightToolStripMenuItem,
            this.centerToolStripMenuItem});
            this.moTextAlign.Name = "moTextAlign";
            this.moTextAlign.Size = new System.Drawing.Size(122, 37);
            this.moTextAlign.Text = "Text-Align";
            this.moTextAlign.ToolTipText = "Set Alignment for the test of the question";
            this.moTextAlign.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.moTextAlign_DropDownItemClicked);
            // 
            // leftToolStripMenuItem
            // 
            this.leftToolStripMenuItem.Name = "leftToolStripMenuItem";
            this.leftToolStripMenuItem.Size = new System.Drawing.Size(164, 34);
            this.leftToolStripMenuItem.Text = "Left";
            // 
            // rightToolStripMenuItem
            // 
            this.rightToolStripMenuItem.Name = "rightToolStripMenuItem";
            this.rightToolStripMenuItem.Size = new System.Drawing.Size(164, 34);
            this.rightToolStripMenuItem.Text = "Right";
            // 
            // centerToolStripMenuItem
            // 
            this.centerToolStripMenuItem.Name = "centerToolStripMenuItem";
            this.centerToolStripMenuItem.Size = new System.Drawing.Size(164, 34);
            this.centerToolStripMenuItem.Text = "Center";
            // 
            // cbFlowDirection
            // 
            this.cbFlowDirection.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topToBottomToolStripMenuItem,
            this.leftToRightToolStripMenuItem,
            this.rightToLeftToolStripMenuItem,
            this.bottomUpToolStripMenuItem});
            this.cbFlowDirection.Name = "cbFlowDirection";
            this.cbFlowDirection.Size = new System.Drawing.Size(112, 37);
            this.cbFlowDirection.Text = "Direction";
            this.cbFlowDirection.ToolTipText = "Set the direction of button alingment";
            this.cbFlowDirection.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.directionToolStripMenuItem_DropDownItemClicked);
            // 
            // topToBottomToolStripMenuItem
            // 
            this.topToBottomToolStripMenuItem.Name = "topToBottomToolStripMenuItem";
            this.topToBottomToolStripMenuItem.Size = new System.Drawing.Size(220, 34);
            this.topToBottomToolStripMenuItem.Text = "Top Down";
            // 
            // leftToRightToolStripMenuItem
            // 
            this.leftToRightToolStripMenuItem.Name = "leftToRightToolStripMenuItem";
            this.leftToRightToolStripMenuItem.Size = new System.Drawing.Size(220, 34);
            this.leftToRightToolStripMenuItem.Text = "Left To Right";
            // 
            // rightToLeftToolStripMenuItem
            // 
            this.rightToLeftToolStripMenuItem.Name = "rightToLeftToolStripMenuItem";
            this.rightToLeftToolStripMenuItem.Size = new System.Drawing.Size(220, 34);
            this.rightToLeftToolStripMenuItem.Text = "Right To Left";
            // 
            // bottomUpToolStripMenuItem
            // 
            this.bottomUpToolStripMenuItem.Name = "bottomUpToolStripMenuItem";
            this.bottomUpToolStripMenuItem.Size = new System.Drawing.Size(220, 34);
            this.bottomUpToolStripMenuItem.Text = "Bottom Up";
            // 
            // borderToolStripMenuItem
            // 
            this.borderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.noneToolStripMenuItem,
            this.singleToolStripMenuItem,
            this.singleDToolStripMenuItem});
            this.borderToolStripMenuItem.Name = "borderToolStripMenuItem";
            this.borderToolStripMenuItem.Size = new System.Drawing.Size(92, 37);
            this.borderToolStripMenuItem.Text = "Border";
            this.borderToolStripMenuItem.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.borderToolStripMenuItem_DropDownItemClicked);
            // 
            // noneToolStripMenuItem
            // 
            this.noneToolStripMenuItem.Name = "noneToolStripMenuItem";
            this.noneToolStripMenuItem.Size = new System.Drawing.Size(191, 34);
            this.noneToolStripMenuItem.Text = "None";
            // 
            // singleToolStripMenuItem
            // 
            this.singleToolStripMenuItem.Name = "singleToolStripMenuItem";
            this.singleToolStripMenuItem.Size = new System.Drawing.Size(191, 34);
            this.singleToolStripMenuItem.Text = "Single";
            // 
            // singleDToolStripMenuItem
            // 
            this.singleDToolStripMenuItem.Name = "singleDToolStripMenuItem";
            this.singleDToolStripMenuItem.Size = new System.Drawing.Size(191, 34);
            this.singleDToolStripMenuItem.Text = "Single 3D";
            // 
            // alignToolStripMenuItem
            // 
            this.alignToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bottomCenterToolStripMenuItem,
            this.bottomLeftToolStripMenuItem,
            this.bottomRightToolStripMenuItem,
            this.middleCenterToolStripMenuItem,
            this.middleLeftToolStripMenuItem,
            this.middleRightToolStripMenuItem,
            this.topCenterToolStripMenuItem,
            this.topLeftToolStripMenuItem,
            this.topRightToolStripMenuItem});
            this.alignToolStripMenuItem.Name = "alignToolStripMenuItem";
            this.alignToolStripMenuItem.Size = new System.Drawing.Size(139, 37);
            this.alignToolStripMenuItem.Text = "Check Align";
            this.alignToolStripMenuItem.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.alignToolStripMenuItem_DropDownItemClicked);
            // 
            // bottomCenterToolStripMenuItem
            // 
            this.bottomCenterToolStripMenuItem.Name = "bottomCenterToolStripMenuItem";
            this.bottomCenterToolStripMenuItem.Size = new System.Drawing.Size(242, 34);
            this.bottomCenterToolStripMenuItem.Text = "Bottom Center";
            // 
            // bottomLeftToolStripMenuItem
            // 
            this.bottomLeftToolStripMenuItem.Name = "bottomLeftToolStripMenuItem";
            this.bottomLeftToolStripMenuItem.Size = new System.Drawing.Size(242, 34);
            this.bottomLeftToolStripMenuItem.Text = "Bottom Left";
            // 
            // bottomRightToolStripMenuItem
            // 
            this.bottomRightToolStripMenuItem.Name = "bottomRightToolStripMenuItem";
            this.bottomRightToolStripMenuItem.Size = new System.Drawing.Size(242, 34);
            this.bottomRightToolStripMenuItem.Text = "Bottom Right";
            // 
            // middleCenterToolStripMenuItem
            // 
            this.middleCenterToolStripMenuItem.Name = "middleCenterToolStripMenuItem";
            this.middleCenterToolStripMenuItem.Size = new System.Drawing.Size(242, 34);
            this.middleCenterToolStripMenuItem.Text = "Middle Center";
            // 
            // middleLeftToolStripMenuItem
            // 
            this.middleLeftToolStripMenuItem.Name = "middleLeftToolStripMenuItem";
            this.middleLeftToolStripMenuItem.Size = new System.Drawing.Size(242, 34);
            this.middleLeftToolStripMenuItem.Text = "Middle Left";
            // 
            // middleRightToolStripMenuItem
            // 
            this.middleRightToolStripMenuItem.Name = "middleRightToolStripMenuItem";
            this.middleRightToolStripMenuItem.Size = new System.Drawing.Size(242, 34);
            this.middleRightToolStripMenuItem.Text = "Middle Right";
            // 
            // topCenterToolStripMenuItem
            // 
            this.topCenterToolStripMenuItem.Name = "topCenterToolStripMenuItem";
            this.topCenterToolStripMenuItem.Size = new System.Drawing.Size(242, 34);
            this.topCenterToolStripMenuItem.Text = "Top Center";
            // 
            // topLeftToolStripMenuItem
            // 
            this.topLeftToolStripMenuItem.Name = "topLeftToolStripMenuItem";
            this.topLeftToolStripMenuItem.Size = new System.Drawing.Size(242, 34);
            this.topLeftToolStripMenuItem.Text = "Top Left";
            // 
            // topRightToolStripMenuItem
            // 
            this.topRightToolStripMenuItem.Name = "topRightToolStripMenuItem";
            this.topRightToolStripMenuItem.Size = new System.Drawing.Size(242, 34);
            this.topRightToolStripMenuItem.Text = "Top Right";
            // 
            // toolStripTextAmoun
            // 
            this.toolStripTextAmoun.Name = "toolStripTextAmoun";
            this.toolStripTextAmoun.Size = new System.Drawing.Size(100, 37);
            this.toolStripTextAmoun.Text = "1";
            this.toolStripTextAmoun.TextChanged += new System.EventHandler(this.toolStripTextAmoun_TextChanged);
            // 
            // txtOptiontxt
            // 
            this.txtOptiontxt.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOptiontxt.Name = "txtOptiontxt";
            this.txtOptiontxt.Size = new System.Drawing.Size(400, 37);
            this.txtOptiontxt.Text = "Enter Option Text";
            this.txtOptiontxt.ToolTipText = "Enter an answer option text";
            // 
            // btnAdd
            // 
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdd.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdd.BackgroundImage")));
            this.btnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAdd.Location = new System.Drawing.Point(1215, 3);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(40, 40);
            this.btnAdd.TabIndex = 7;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnDelete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDelete.BackgroundImage")));
            this.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDelete.Location = new System.Drawing.Point(1277, 5);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(40, 40);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // cbRequired
            // 
            this.cbRequired.AutoSize = true;
            this.cbRequired.Location = new System.Drawing.Point(17, 55);
            this.cbRequired.Name = "cbRequired";
            this.cbRequired.Size = new System.Drawing.Size(100, 24);
            this.cbRequired.TabIndex = 9;
            this.cbRequired.Text = "Required";
            this.cbRequired.UseVisualStyleBackColor = true;
            // 
            // txtVarName
            // 
            this.txtVarName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtVarName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVarName.Location = new System.Drawing.Point(1002, 55);
            this.txtVarName.Multiline = true;
            this.txtVarName.Name = "txtVarName";
            this.txtVarName.Size = new System.Drawing.Size(210, 34);
            this.txtVarName.TabIndex = 10;
            this.txtVarName.Text = "Variable Name";
            this.toolTip1.SetToolTip(this.txtVarName, "Enter a Variable Name for easy SSPS import");
            this.txtVarName.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtVarName_MouseClick);
            this.txtVarName.MouseLeave += new System.EventHandler(this.txtVarName_MouseLeave);
            // 
            // toolTip1
            // 
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // Panel1
            // 
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Azure;
            this.Controls.Add(this.txtVarName);
            this.Controls.Add(this.cbRequired);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.flpResponse);
            this.Controls.Add(this.txtQuestionText);
            this.Controls.Add(this.chbxWrap);
            this.Controls.Add(this.menuStripEdit);
            this.Name = "Panel1";
            this.Size = new System.Drawing.Size(1341, 260);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.Panel1_DragDrop);
            this.menuStripEdit.ResumeLayout(false);
            this.menuStripEdit.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
        private System.Windows.Forms.CheckBox chbxWrap;
        private System.Windows.Forms.TextBox txtQuestionText;
        private System.Windows.Forms.FlowLayoutPanel flpResponse;
        private System.Windows.Forms.MenuStrip menuStripEdit;
        private System.Windows.Forms.ToolStripMenuItem fontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem moFontLabel;
        private System.Windows.Forms.ToolStripMenuItem moFontResponse;
        private System.Windows.Forms.ToolStripMenuItem moTextAlign;
        private System.Windows.Forms.ToolStripMenuItem leftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem centerToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox txtOptiontxt;
        private System.Windows.Forms.ToolStripMenuItem cbFlowDirection;
        private System.Windows.Forms.ToolStripMenuItem topToBottomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leftToRightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rightToLeftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomUpToolStripMenuItem;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.ToolStripMenuItem borderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem singleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem noneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem singleDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alignToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomCenterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomLeftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomRightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem middleCenterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem middleLeftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem middleRightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem topCenterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem topLeftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem topRightToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox toolStripTextAmoun;
        private System.Windows.Forms.CheckBox cbRequired;
        private System.Windows.Forms.TextBox txtVarName;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}
