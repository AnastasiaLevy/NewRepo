﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TestSite
{
    public partial class TrailsPage : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
     

        }
        [WebMethod]
        public static void Save_Data(string name)
        {
            var one = name;
        }
    }
}