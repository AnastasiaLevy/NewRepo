﻿window.onload = function () {
    RunDemoTest();
};

function RunDemoTest() {
    if (typeof paper == 'object')
        paper.remove();
    var message = getMessage("test")
    displayInstructions(message);
    $('#displayMessage').click(function () {
        startTrailTest();
    });



    function startTrailTest() {
        if (typeof paper == 'object')
            paper.remove();
        document.getElementById("displayMessage").hidden = true;
        document.getElementById("canvas_container").hidden = false;

        var paper = new Raphael(document.getElementById('canvas_container'), 1000, 700);
        var selected = "";
        var prev = "";
        var correct = "";
        var start = paper.text(571, 378, "Start")
        .attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" });
        var finish = paper.text(675, 665, "Finish")
        .attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" });



        var c1 = paper.circle(572, 338, 30);
        var t1 = paper.text(572, 338, "1");


        c1.attr({ fill: 'white', stroke: '#000000' });
        c1.id = "1";
        c1.glow({
            color: "#D3D3D3",
            width: 20,
            opacity: 0.9,
        });

        c1.node.onclick = function () {
            c1.glow({
                color: "#FFFFFF",
                width: 30,
                opacity: 1,
            });
            if (selected == "")
                selected = c1.id;
            else {
                var right = "0";
                if (right != selected) {
                    blink(c1);
                    blinkText(t1);
                
                }
            }
        }

        t1.attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" })
        t1.node.onclick = function () {
            c1.glow({
                color: "#FFFFFF",
                width: 20,
                opacity: 1.0,
            });
            if (selected == "")
                selected = c1.id;
            else {
                var right = "0";
                if (right != selected) {
                    blink(c1);
                    blinkText(t1);
                
                }
            }
        }

        var c2 = new makeMyObj(2, 375, 450, 30, "2", "M 587 343  L 360 450")
        var c3 = new makeMyObj(3, 637, 500, 30, "3", "M 375 450  L 637 500");
        var c4 = new makeMyObj(4, 632, 200, 30, "4", "M 637 500  L 632 200");
        var c5 = new makeMyObj(5, 312, 250, 30, "5", "M 632 200  L 312 250");
        var c6 = new makeMyObj(6, 475, 300, 30, "6", "M 312 250  L 475 300");
        var c7 = new makeMyObj(7, 300, 387, 30, "7", "M 475 300  L 300 387");
        var c8 = new makeMyObj(8, 200, 512, 30, "8", "M 300 387  L 200 512", true);

        function makeMyObj(id, x, y, rad, text, path, last) {

            var cName = "c" + id;
            var tName = "t" + id;
            var cName = paper.circle(x, y, rad);
            var tName = paper.text(x, y, text);

            cName.attr({ fill: 'white', stroke: '#000000' });
            cName.id = id;
            cName.node.onclick = function () {
                var right = id - 1;
                if (right == selected) {

                    if (last) {
                        cName.glow({
                            color: "#D3D3D3",
                            width: 20,
                            opacity: 0.9,
                        });
                        paper.remove();
                        var message = getMessage("trailsA")
                        displayInstructions(message);
                        $('#displayMessage').click(function () {

                            startTrailA();
                        });

                    }
                    else {

                        selected = cName.id;
                        makeLine(path, paper);
                    }

                }
                else {
                    blink(cName);
                    blinkText(tName);
                   
                }
            }

            tName.attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" })
            tName.node.onclick = function () {
                var right = id - 1;
                if (right == selected) {
                    if (last) {
                        cName.glow({
                            color: "#D3D3D3",
                            width: 20,
                            opacity: 0.9,
                        });
                        paper.remove();
                        var message = getMessage("trailsA")
                        displayInstructions(message);
                        $('#displayMessage').click(function () {
                            startTrailA();
                        });

                        //passResults();

                    } else
                        makeLine(path, paper);
                    selected = cName.id;
                }
                else {
                    blink(cName);
                    blinkText(tName);
                   
                }
            }
        }

        }
    };

    function displayInstructions(text) {

        document.getElementById("canvas_container").hidden = true;
        document.getElementById("displayMessage").hidden = false;
        document.getElementById("displayMessage").innerHTML = text;

    }


    function makeMyObj(id, x, y, rad, text, path, last) {

        var cName = "c" + id;
        var tName = "t" + id;
        var cName = paper.circle(x, y, rad);
        var tName = paper.text(x, y, text);

        cName.attr({ fill: 'white', stroke: '#000000' });
        cName.id = id;
        cName.node.onclick = function () {
            var right = id - 1;
            if (right == selected) {

                if (last) {
                  
                    cName.glow({
                        color: "#D3D3D3",
                        width: 20,
                        opacity: 0.9,
                    });
                    //passResults();
                    paper.clear();
                }
                else

                    selected = cName.id;
                makeLine(path, paper);

            }
            else {
                blink(cName);
                blinkText(tName);
             
            }
        }

        tName.attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" })
        tName.node.onclick = function () {
            var right = id - 1;
            if (right == selected) {
                if (last) {
                
                    cName.glow({
                        color: "#D3D3D3",
                        width: 20,
                        opacity: 0.9,
                    });
                    //passResults();

                } else
                    makeLine(path, paper);
                selected = cName.id;
            }
            else {
                blink(cName);
                blinkText(tName);
             
            }
        }
    }

    function startTrailTestB() {
        if (typeof paper == 'object')
            paper.remove();
        document.getElementById("displayMessage").hidden = true;
        document.getElementById("canvas_container").hidden = false;

        var paper = new Raphael(document.getElementById('canvas_container'), 1000, 700);
        var selected = "";
        var prev = "";
        var correct = "";
        var start = paper.text(431, 420, "Start")
        .attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" });
        var finish = paper.text(441, 270, "Finish")
        .attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" });



        var c1 = paper.circle(430, 380, 30);
        var t1 = paper.text(430, 380, "1");


        c1.attr({ fill: 'white', stroke: '#000000' });
        c1.id = "1";
        c1.glow({
            color: "#D3D3D3",
            width: 20,
            opacity: 0.9,
        });

        c1.node.onclick = function () {
            c1.glow({
                color: "#FFFFFF",
                width: 30,
                opacity: 1,
            });
            if (selected == "")
                selected = c1.id;
            else {
                var right = "0";
                if (right != selected) {
                    blink(c1);
                    blinkText(t1);
                 
                }
            }
        }

        t1.attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" })
        t1.node.onclick = function () {
            c1.glow({
                color: "#FFFFFF",
                width: 20,
                opacity: 1.0,
            });
            if (selected == "")
                selected = c1.id;
            else {
                var right = "0";
                if (right != selected) {
                    blink(c1);
                    blinkText(t1);
                
                }
            }
        }

        var c2 = new makeMyObj(2, 590, 200, 30, "A", "M 430 380  L 590 200")
        var c3 = new makeMyObj(3, 820, 460, 30, "2", "M 590 200  L 820 460");
        var c4 = new makeMyObj(4, 600, 340, 30, "B", "M 820 460  L 600 340");
        var c5 = new makeMyObj(5, 690, 570, 30, "3", "M 600 340  L 690 570");
        var c6 = new makeMyObj(6, 340, 560, 30, "C", "M 690 570  L 340 560");
        var c7 = new makeMyObj(7, 220, 180, 30, "4", "M 340 560  L 220 180");
        var c8 = new makeMyObj(8, 440, 230, 30, "D", "M 220 180  L 440 230", true);

        function makeMyObj(id, x, y, rad, text, path, last) {

            var cName = "c" + id;
            var tName = "t" + id;
            var cName = paper.circle(x, y, rad);
            var tName = paper.text(x, y, text);

            cName.attr({ fill: 'white', stroke: '#000000' });
            cName.id = id;
            cName.node.onclick = function () {
                var right = id - 1;
                if (right == selected) {

                    if (last) {
                        cName.glow({
                            color: "#D3D3D3",
                            width: 20,
                            opacity: 0.9,
                        });
                        paper.remove();
                        var message = getMessage("trailsB")
                        displayInstructions(message);
                        $('#displayMessage').click(function () {
                            startTrailB();
                        });
                    }
                    else {

                        selected = cName.id;
                        makeLine(path, paper);
                    }
                }
                else {
                    blink(cName);
                    blinkText(tName);
                
                }
            }

            tName.attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" })
            tName.node.onclick = function () {
                var right = id - 1;
                if (right == selected) {
                    if (last) {

                        cName.glow({
                            color: "#D3D3D3",
                            width: 20,
                            opacity: 0.9,
                        });
                        //paper.clear();
                        paper.remove();
                        var message  = getMessage("trailsB")
                        displayInstructions(message);
                        $('#displayMessage').click(function () {
                            startTrailB();
                        });

                        //passResults();

                    } else
                        makeLine(path, paper);
                    selected = cName.id;
                }
                else {
                    blink(cName);
                    blinkText(tName);
               
                }
            }
        }


    };

    function startTrailA() {
        if (typeof paper == 'object')
            paper.remove();
        var paper = new Raphael(document.getElementById('canvas_container'), 1000, 700);
        var selected = "";
        var prev = "";
        var correct = "";
        var start = paper.text(571, 378, "Start")
        .attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" });
        var finish = paper.text(675, 665, "Finish")
        .attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" });



        var c1 = paper.circle(572, 338, 30);
        var t1 = paper.text(572, 338, "1");


        c1.attr({ fill: 'white', stroke: '#000000' });
        c1.id = "1";
        c1.glow({
            color: "#D3D3D3",
            width: 20,
            opacity: 0.9,
        });

        c1.node.onclick = function () {
            c1.glow({
                color: "#FFFFFF",
                width: 30,
                opacity: 1,
            });
            if (selected == "")
                selected = c1.id;
            else {
                var right = "0";
                if (right != selected) {
                    blink(c1);
                    blinkText(t1);
                 
                }
            }
        }

        t1.attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" })
        t1.node.onclick = function () {
            c1.glow({
                color: "#FFFFFF",
                width: 20,
                opacity: 1.0,
            });
            if (selected == "")
                selected = c1.id;
            else {
                var right = "0";
                if (right != selected) {
                    blink(c1);
                    blinkText(t1);
                
                }
            }
        }

        var c2 = new makeMyObj(2, 375, 450, 30, "2", "M 587 343  L 360 450")
        var c3 = new makeMyObj(3, 637, 500, 30, "3", "M 375 450  L 637 500");
        var c4 = new makeMyObj(4, 632, 200, 30, "4", "M 637 500  L 632 200");
        var c5 = new makeMyObj(5, 312, 250, 30, "5", "M 632 200  L 312 250");
        var c6 = new makeMyObj(6, 475, 300, 30, "6", "M 312 250  L 475 300");
        var c7 = new makeMyObj(7, 300, 387, 30, "7", "M 475 300  L 300 387");
        var c8 = new makeMyObj(8, 200, 512, 30, "8", "M 300 387  L 200 512");
        var c9 = new makeMyObj(9, 250, 612, 30, "9", "M 200 512  L 250 612");
        var c10 = new makeMyObj(10, 300, 482, 30, "10", "M 250 612  L 300 482");
        var c11 = new makeMyObj(11, 500, 637, 30, "11", "M 300 482  L 500 637");
        var c12 = new makeMyObj(12, 75, 662, 30, "12", "M 500 637  L 75  662");
        var c13 = new makeMyObj(13, 150, 337, 30, "13", "M 75  662  L 150 337");
        var c14 = new makeMyObj(14, 37, 437, 30, "14", "M 150 337  L 37 437");
        var c15 = new makeMyObj(15, 50, 75, 30, "15", "M 37  437  L 50 75,");
        var c16 = new makeMyObj(16, 172, 225, 30, "16", "M 50  75,  L 172 225");
        var c17 = new makeMyObj(17, 412, 62, 30, "17", "M 172 225  L 412 62");
        var c18 = new makeMyObj(18, 412, 207, 30, "18", "M 412 62  L 412 207");
        var c19 = new makeMyObj(19, 687, 112, 30, "19", "M 412 207  L 687 112");
        var c20 = new makeMyObj(20, 535, 110, 30, "20", "M 687 112  L 535 110");
        var c21 = new makeMyObj(21, 825, 50, 30, "21", "M 535 110  L 825 50");
        var c22 = new makeMyObj(22, 800, 275, 30, "22", "M 825 50  L 800 275");
        var c23 = new makeMyObj(23, 830, 650, 30, "23", "M 800 275  L 830 650");
        var c24 = new makeMyObj(24, 725, 337, 30, "24", "M 830 650  L 725 337");
        var c25 = new makeMyObj(25, 675, 625, 30, "25", "M 725 337  L 675 625", true);


        function makeMyObj(id, x, y, rad, text, path, last) {

            var cName = "c" + id;
            var tName = "t" + id;
            var cName = paper.circle(x, y, rad);
            var tName = paper.text(x, y, text);

            cName.attr({ fill: 'white', stroke: '#000000' });
            cName.id = id;
            cName.node.onclick = function () {
                var right = id - 1;
                if (right == selected) {

                    if (last) {
                       
                        cName.glow({
                            color: "#D3D3D3",
                            width: 20,
                            opacity: 0.9,
                        });
                        //passResults();
                        paper.remove();
                        var message = getMessage("testB")
                        displayInstructions(message);
                        $('#displayMessage').click(function () {
                           
                            startTrailTestB();
                        });


                    }
                    else

                        selected = cName.id;
                    makeLine(path, paper);

                }
                else {
                    blink(cName);
                    blinkText(tName);
                 
                }
            }

            tName.attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" })
            tName.node.onclick = function () {
                var right = id - 1;
                if (right == selected) {
                    if (last) {
                        
                        cName.glow({
                            color: "#D3D3D3",
                            width: 20,
                            opacity: 0.9,
                        });

                        var message = getMessage("trailB");
                        displayInstructions(text);
                        $('#displayMessage').click(function () {
                            startTrailTestB();
                        });
                        //passResults();

                    } else
                       
                    makeLine(path, paper);
                    selected = cName.id;
                }
                else {
                    blink(cName);
                    blinkText(tName);
                
                }
            }
        }

    };




    function startTrailB() {
        if (typeof paper == 'object')
            paper.remove();
        document.getElementById("displayMessage").hidden = true;
        document.getElementById("canvas_container").hidden = false;

        var paper = new Raphael(document.getElementById('canvas_container'), 1000, 700);
        var selected = "";
        var prev = "";
        var correct = "";
        var start = paper.text(571, 378, "Start")
        .attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" });
        var finish = paper.text(675, 665, "Finish")
        .attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" });



        var c1 = paper.circle(572, 338, 30);
        var t1 = paper.text(572, 338, "1");


        c1.attr({ fill: 'white', stroke: '#000000' });
        c1.id = "1";
        c1.glow({
            color: "#D3D3D3",
            width: 20,
            opacity: 0.9,
        });

        c1.node.onclick = function () {
            c1.glow({
                color: "#FFFFFF",
                width: 30,
                opacity: 1,
            });
            if (selected == "")
                selected = c1.id;
            else {
                var right = "0";
                if (right != selected) {
                    blink(c1);
                    blinkText(t1);
                   
                }
            }
        }

        t1.attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" })
        t1.node.onclick = function () {
            c1.glow({
                color: "#FFFFFF",
                width: 20,
                opacity: 1.0,
            });
            if (selected == "")
                selected = c1.id;
            else {
                var right = "0";
                if (right != selected) {
                    blink(c1);
                    blinkText(t1);
                   
                }
            }
        }

        var ca = new makeMyObj(2, 600, 500, 30, "A", "M 572 338  L 600 500")
        var c2 = new makeMyObj(3, 270, 540, 30, "2", "M 600 500  L 270 540,");
        var cb = new makeMyObj(4, 330, 150, 30, "B", "M 270 540  L 330 150");
        var c3 = new makeMyObj(5, 410, 240, 30, "3", "M 330 150  L 410 240,");
        var cc = new makeMyObj(6, 560, 400, 30, "C", "M 410 240 L 560 400,,");
        var c4 = new makeMyObj(7, 420, 130, 30, "4", "M 560 400  L 420 130");
        var cd = new makeMyObj(8, 700, 85, 30, "D", "M 420 130  L 700 85");
        var c5 = new makeMyObj(9, 700, 320, 30, "5", "M 700 85  L 700 320");
        var ce = new makeMyObj(10, 730, 580, 30, "E", "M 700 320  L 730 580,");
        var c6 = new makeMyObj(11, 360, 570, 30, "6", "M 730 580  L 360 570");
        var cf = new makeMyObj(12, 170, 630, 30, "F", "M 360 570  L 170 630");
        var c7 = new makeMyObj(13, 270, 300, 30, "7", "M 170 630  L 270 300,");
        var cg = new makeMyObj(14, 150, 440, 30, "G", "M 270 300  L 150 440");
        var c8 = new makeMyObj(15, 100, 80, 30, "8", "M 150 440  L 100 80");
        var ch = new makeMyObj(16, 170, 360, 30, "H", "M 100 80  L 170 360");
        var c9 = new makeMyObj(17, 210, 90, 30, "9", "M 170 360  L 210 90");
        var ci = new makeMyObj(18, 540, 60, 30, "I", "M 210 90  L 540 60");
        var c10 = new makeMyObj(19, 850, 50, 30, "10", "M 540 60  L 850 50");
        var cj = new makeMyObj(20, 780, 510, 30, "J", "M 850 50  L 780 510,");
        var c11 = new makeMyObj(21, 820, 660, 30, "11", "M 780 510 L 820 660");
        var ck = new makeMyObj(22, 40, 660, 30, "K", "M 820 660 L 40 660");
        var c12 = new makeMyObj(23, 50, 380, 30, "12", "M 40 660  L 50 380");
        var cl = new makeMyObj(24, 105, 555, 30, "L", "M 50 380  L 105 555");
        var c13 = new makeMyObj(25, 30, 30, 30, "13", "M 105 555  L 30 30,", true);

        function makeMyObj(id, x, y, rad, text, path, last) {

            var cName = "c" + id;
            var tName = "t" + id;
            var cName = paper.circle(x, y, rad);
            var tName = paper.text(x, y, text);

            cName.attr({ fill: 'white', stroke: '#000000' });
            cName.id = id;
            cName.node.onclick = function () {
                var right = id - 1;
                if (right == selected) {

                    if (last) {
                        
                        cName.glow({
                            color: "#D3D3D3",
                            width: 20,
                            opacity: 0.9,
                        });
                        //passResults();
                        paper.remove;
                    }
                    else

                        selected = cName.id;
                    makeLine(path, paper);

                }
                else {
                    blink(cName);
                    blinkText(tName);
                  
                }
            }

            tName.attr({ "font-size": 20, "font-family": "Arial, Helvetica, sans-serif" })
            tName.node.onclick = function () {
                var right = id - 1;
                if (right == selected) {
                    if (last) {
                      
                        cName.glow({
                            color: "#D3D3D3",
                            width: 20,
                            opacity: 0.9,
                        });
                        makeLine(path, paper);
                        displayInstructions("The Test is Finished");
                        //passResults();
                    } else
                        makeLine(path, paper);
                    selected = cName.id;
                }
                else {
                    blink(cName);
                    blinkText(tName);
 
                }
            }
        }
};




function getMessage(type) {
    var message = ""
    switch (type) {
        case "test":
            message =
                ["You are going to see 8 circles containing",
    "the numbers from 1 to 8. I want you to begin",
    "by clicking the circle containing the number 1",
    "then click the circle containing the number 2.",
    "Continue clicking each circle in order until",
    "you have clicked all the circles from 1 to 8.",
    "  ",
    "Click anywhere on this message to begin."].join("\n");
            break;
        case "trailsA":
            message =
                ["Like the last time you are going to see some",
    "circles containing numbers, only this time there",
    "will be 25 circles containing the numbers from",
    "1 to 25. As you did on the last trial I want you",
    "to begin clicking the circle containing the",
    "number 1. Click on each circle in order until you",
    "reach the circle containing the number 25.",
    "Work as quickly and accurately as possible.",
    "Click anywhere on this message to begin."].join("\n");
            break;
        case "testB":
            message = ["Like the first trial, you are going to see 8",
     "circles. Only this time half of the circles",
"will contain numbers, the numbers from 1 to 4",
"and the other half will contain letters, the",
"letters 'A' to 'D'. I want you to begin by",
"the circle containing the number 1 then click",
"the circle containing the letter 'A'. Next",
"Next click the circle containing the number 2,",
"continue clicking the circles in ascending",
"order alternating between numbers and letters",
"until you have clicked all the circles.",
"Click anywhere on this message to begin."].join("\n");
            break;
        case "trailsB":
            message = ["Change plz"].join("\n");


    }
    return message;
}

function blink(object) {
    object.attr({ stroke: 'red' });
    setTimeout(function () { object.attr({ stroke: '#000000' }); }, 500);
}

function blinkText(object) {
    object.attr({ fill: 'red' });
    setTimeout(function () { object.attr({ fill: '#000000' }); }, 500);

}

function makeLine(string, paper) {
    var line = paper.path(string);
    line.toBack();
}

function play() {
    //var audio = document.getElementById('audio1');
    //if (audio.paused) {
    //    audio.play();
    //} else {
    //    audio.currentTime = 0
    //}
}
function passResults() {
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: 'TrailsPage.aspx/Save_Data',
        data: '{name:"someVal"}',
        type: 'POST',
        success: function (resp) {
            //request sent and response received.
            alert("back");
        }
    });
}

//}