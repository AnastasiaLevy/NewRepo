﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace TestSite
{
    public partial class MainPage : System.Web.UI.Page
    {
        protected void Page_Init(object sender, EventArgs e)
        {
            if (User.Identity.IsAuthenticated)
            {
                login.Visible = false;
                logOut.Visible = true;
                profOpt.Visible = true;
            }
            else
            {
                login.Visible = true;
                logOut.Visible = false;
                profOpt.Visible = false;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
         
         
           
        }
        protected void logOut_Click(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            Response.Redirect("~/MainPage.aspx");
            
        }

        protected void clcLogin(object sender, EventArgs e)
        {

            var provider = Membership.Provider;
            string name = provider.ApplicationName;

            if (Membership.ValidateUser(userNameLg.Value, userPwLg.Value))
            {
                User.ToString();
                FormsAuthentication.SetAuthCookie(userNameLg.Value, true);
                Session["Username"] = userNameLg.Value;
                Response.Redirect("~/UserProfile.aspx");
                wrongLogin.Text = "";
          
            }
            else
            {
                wrongLogin.Text = "*Username or Password were incorrect";
             
            }
            
        }
        protected void clcSendButton (object sender, EventArgs e)
        {
            string txtNameFrom = emailName.Value;
            string txtEmailFrom = emailFrom.Value;
            string txtMessage = emailText.Value;

       MailMessage mailObj = new MailMessage(
            "analescheok@hotmail.com", "analescheok@gmail.com", "hello", "text");
       SmtpClient SMTPServer = new SmtpClient("smtp.gmail.com");//"207.46.163.170"
       SMTPServer.Port = 587;
       SMTPServer.EnableSsl = true;
       new System.Net.NetworkCredential("analescheok@gmail.com", "Ana9487LA");
        try
        {
            SMTPServer.Send(mailObj);
        }
        catch (Exception ex)
        {
            //Label1.Text = ex.ToString();
        }

       
        }
        //protected void Register_Single(object sender, EventArgs e)
        //{
          
          
        //    MembershipUser user = Membership.CreateUser(singleName.Text, singlePw.Text,single_email.Text);

        //    if (Membership.ValidateUser(singleName.Text, singlePw.Text))
        //    {
        //        FormsAuthentication.SetAuthCookie(singleName.Text, true);
        //        Session["Username"] = singleName.Text;
        //        Response.Redirect("~/UserProfile.aspx");
        //    }

        //}
        protected void Register_Provider(object sender, EventArgs e)
        {
            MembershipCreateStatus createStatus;
            MembershipUser user = Membership.CreateUser(provName.Text, provPw.Text, prov_email.Text);

            if (Membership.ValidateUser(provName.Text, provPw.Text))
            {
                Session["Username"] = provName.Text;
                Response.Redirect("~/UserPortal.aspx");
            }


        }

        protected void regProv_Click(object sender, EventArgs e)
        {
        
        }

        protected void regSingle_Click(object sender, EventArgs e)
        {
            MembershipCreateStatus createStatus;
            MembershipUser user = Membership.CreateUser(provName.Text, provPw.Text, prov_email.Text);

        }
    }
}