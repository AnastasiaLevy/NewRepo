﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TestSite.DAL;

namespace TestSite
{
    public partial class UserPortal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            InitTimeLine();
            SetUserName();

        }

        private void SetUserName()
        {
            //lblDisplayUser.Text = Session["Username"].ToString();
        }

        private void InitTimeLine()
        {
            DataTable events = DataMethods.GetEvents();
            if (events.Rows.Count > 0)
            {
                Panel pnl = new Panel();
                int i =1;
                string style = "";
                foreach (DataRow dr in events.Rows)
                {
                    if (i % 2 == 0)
                        style = "inverted";
                    else if (i % 3 == 0)
                        style = "centered";
                    pnl.Controls.Add(new LiteralControl("<h2>" + dr["date"].ToString() + "</h2>"));

                    pnl.Controls.Add(new LiteralControl(String.Format("<ul class='timeline-items'> <li class='is-hidden timeline-item {0}'>  <h3>{1}</h3><hr> <p>{2} </p> <hr> <time>{3}</time><p><a href='{4}'>Link</a></p></li> </ul>",
                                                                         style, dr["title"].ToString(), dr["Description"].ToString(), dr["date"].ToString(), dr["link"].ToString())));
                    phTimeLine.Controls.Add(pnl);
                    i++;
                }
            }                                               
                                                          
                                                    
                                                      
        }
    }
}