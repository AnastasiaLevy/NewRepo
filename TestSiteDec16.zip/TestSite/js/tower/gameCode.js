﻿function startGame(gameNum)
{
    nm = 0;
    if (gameNum == 1) {
        displayInstructions("Some words");
        var field = document.getElementById("countdown");
        field.style.display = 'none';
        totalTime = getTime();
    }
    else {
        //startCountDownTimer(gameNum);
    }
    //
    initField();
    showImage(gameNum);
    game = gameNum;
    if (game == 1) //TODO: change back!
    {
        time = getTime();

    }
    
}

function displayInstructions(text) {
    var field = document.getElementById("displayMessageL");
    field.textContent = text;
    field.onclick= function run() {
        canMove = true;
       
        field.style.display = 'none';
    }

}

function startCountDownTimer(game) {
    var timeleft = 2;
    canMove = false;
    var field = document.getElementById("countdown");
    field.style.display = '';
    if (game > 1)
    {

    }
    field.innerHTML = "Please wait <span id='countdowntimer'>2 </span> seconds";
    var div = document.getElementById("countdowntimer");
    var downloadTimer = setInterval(function () {
        timeleft--;
        div.textContent = timeleft;
        if (timeleft <= 0) {

            clearInterval(downloadTimer);
            field.textContent = "Click to Start";

           
        
        }

    }, 1000);

    field.onclick = function run() {
        canMove = true;
        //gameStarted = true;
        cleanDivs();
        field.style.display = 'none'
        startGame(game)

    }
}

function checkPos(out) {
    canMove = false;
    setTimeout(function () { canMove = true }, 1200);
    if (out)
    {
       
        initTTime = new Date() - time;
        alert("Initial Think Time: " + initTTime);
    }
    if (game == 1)
    {
   
        if (p5 != null && p5.id == "blue" &&
            p3 != null && p3.id == "green" &&
            p6 != null && p6.id == "red") {

            over = new Date() - time;
            alert("Total Moves: " + nm);
            alert("This round time: " + over);
           
            gameFinished = true;
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            return;
        }
    }
    else if (game == 2)
    {
        if (p5 != null && p5.id == "red" &&
            p3 != null && p3.id == "green" &&
            p6 != null && p6.id == "blue") {
            
            over = new Date() - time;
            alert("Total Moves: " + nm);
            alert("This round time: " + over);
           
        
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            return;
        }
    }
    else if (game == 3) {
        if (p6 != null && p6.id == "red" &&
            p3 != null && p3.id == "green" &&
            p2 != null && p2.id == "blue") {
            alert(nm);
            over = new Date() - time;
            alert(over);
            gameFinished = true;
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            return;
        }
    }
    else if (game == 4) {
        if (p5 != null && p5.id == "red" &&
            p4 != null && p4.id == "green" &&
            p3 != null && p3.id == "blue") {
            alert(nm);
            over = new Date() - time;
            alert(over);
            gameFinished = true;
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            return;
        }
    }
    else if (game == 5) {
        if (p5 != null && p5.id == "red" &&
            p6 != null && p6.id == "green" &&
            p4 != null && p4.id == "blue") {
            alert(nm);
            gameFinished = true;
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            return;
        }
    }
    else if (game == 6) {
        if (p5 != null && p5.id == "red" &&
            p3 != null && p3.id == "blue" &&
            p2 != null && p2.id == "green") {
            alert(nm);
            over = new Date() - time;
            alert(over);
            gameFinished = true;
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            return;
        }
    }
    else if (game == 7) {
        if (p5 != null && p5.id == "red" &&
         p6 != null && p6.id == "green" &&
         p3 != null && p3.id == "blue") {
            alert(nm);
            over = new Date() - time;
            alert(over);
            gameFinished = true;
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            return;
        }
    }
    else if (game == 8) {
        if (p3 != null && p3.id == "red" &&
         p2 != null && p2.id == "green" &&
         p6 != null && p6.id == "blue") {
            alert(nm);
            over = new Date() - time;
            alert(over);
            gameFinished = true;
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            return;
        }
    }
    else if (game == 9) {
        if (p1 != null && p1.id == "red" &&
         p2 != null && p2.id == "green" &&
         p3 != null && p3.id == "blue") {
            alert(nm);
            over = new Date() - time;
            alert(over);
            gameFinished = true;
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            return;
        }
    }
    else if (game == 10) {
        if (p2 != null && p2.id == "red" &&
         p3 != null && p3.id == "blue" &&
         p6 != null && p6.id == "green") {
            alert(nm);
            over = new Date() - time;
            alert(over);
            gameFinished = true;
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            return;
        }
    }
    else if (game == 11) {
        if (p6 != null && p6.id == "red" &&
         p2 != null && p2.id == "green" &&
         p3 != null && p3.id == "blue") {
            alert(nm);
            over = new Date() - time;
            alert(over);
            gameFinished = true;
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            return;
        }
    }
    else if (game == 12) {
        if (p2 != null && p2.id == "red" &&
            p1 != null && p1.id == "green" &&
            p3 != null && p3.id == "blue") {
            alert(nm);
            over = new Date() - time;
            alert(over);
            gameFinished = true;
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            return;
        }
    }
    else if (game == 13) {
        if (p2 != null && p2.id == "red" &&
         p5 != null && p5.id == "green" &&
         p3 != null && p3.id == "blue") {
            alert(nm);
            over = new Date() - time;
            alert(over);
            gameFinished = true;
            canMove = false;
            game = game + 1;
            startCountDownTimer(game);
            totalTime = new Date() - time;
            return;
        }
    }


};

function getTime() {

        return new Date();
    }


function cleanDivs() {
    //var ele = $("#canvas_container");
    $("#canvas_small").remove();
    $("#testArea").append("<div id = 'canvas_small' class='left'></div>");
    $("#image_holder").remove();
    $("#testArea").append("<div id = 'image_holder' class='display'></div>");

}